<?php
require 'auth.php';
checkLevel(2); // Only for Accommodation Managers
require 'db_connect.php';

$order = isset($_GET['sort']) && $_GET['sort'] === 'desc' ? 'DESC' : 'ASC';

$query = "
    SELECT ar.*, u.full_name AS student_name, c.college_name, m.full_name AS manager_name
    FROM accommodation_records ar
    JOIN users u ON ar.student_id = u.user_id
    JOIN colleges c ON ar.college_id = c.college_id
    JOIN users m ON ar.approved_by = m.user_id
    ORDER BY student_name $order
";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>All Accommodation Records</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="record_manager.css" />
</head>
<body>

  <!-- Navbar -->
  <nav class="navbar">
    <div class="navbar-logo">
      <h1>Student College Accommodation System</h1>
    </div>
    <ul class="navbar-links">
      <li><a href="manager_dashboard.php">Dashboard</a></li>
      <li><a href="edit_profile.php">Profile</a></li>
      <li><a href="view_applications.php">Manage Applications</a></li>
      <li><a href="manager_accommodation_record.php">Accommodation Record</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>

  <div class="record-container">
    <h2 class="record-title">All Accommodation Records</h2>

    <div class="sort-links">
      Sort by Student:
      <a href="?sort=asc">A–Z</a> |
      <a href="?sort=desc">Z–A</a>
    </div>

    <?php if ($result->num_rows > 0): ?>
    <div class="record-table-wrapper">
      <table class="record-table">
        <thead>
          <tr>
            <th>Semester</th>
            <th>Student Name</th>
            <th>College</th>
            <th>Approved By</th>
            <th>Approval Date</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($row['semester']) ?></td>
            <td><?= htmlspecialchars($row['student_name']) ?></td>
            <td><?= htmlspecialchars($row['college_name']) ?></td>
            <td><?= htmlspecialchars($row['manager_name']) ?></td>
            <td><?= htmlspecialchars($row['approve_date']) ?></td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
      <p class="no-record">⚠️ No accommodation records found.</p>
    <?php endif; ?>

    <div class="record-back">
      <a href="manager_dashboard.php">← Back to Dashboard</a>
    </div>
  </div>

</body>
</html>
