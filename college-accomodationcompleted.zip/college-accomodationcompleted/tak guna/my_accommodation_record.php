<?php
require 'auth.php';
checkLevel(3); // Only for students
require 'db_connect.php';

$user_id = $_SESSION['user_id'];

// Fetch approved accommodation records for the student
$stmt = $conn->prepare("
    SELECT ar.*, c.college_name, u.full_name AS manager_name
    FROM accommodation_records ar
    JOIN colleges c ON ar.college_id = c.college_id
    JOIN users u ON ar.approved_by = u.user_id
    WHERE ar.student_id = ?
    ORDER BY ar.approve_date DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>My Accommodation Record</title>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="record.css" />
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar">
      <div class="navbar-logo">
        <h1>Student College Accommodation System</h1>
      </div>
      <ul class="navbar-links">
        <li><a href="student_dashboard.php">Dashboard</a></li>
        <li><a href="apply_accommodation.php">Apply</a></li>
        <li><a href="view_my_application.php">My Applications</a></li>
        <li><a href="edit_profile.php">Profile</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    </nav>

    <div class="record-container">
      <h2 class="record-title">My Accommodation Records</h2>

      <?php if ($result->num_rows > 0): ?>
        <div class="record-table-wrapper">
          <table class="record-table">
            <thead>
              <tr>
                <th>Semester</th>
                <th>College</th>
                <th>Approved By</th>
                <th>Approval Date</th>
              </tr>
            </thead>
            <tbody>
              <?php while ($row = $result->fetch_assoc()): ?>
              <tr>
                <td><?= htmlspecialchars($row['semester']) ?></td>
                <td><?= htmlspecialchars($row['college_name']) ?></td>
                <td><?= htmlspecialchars($row['manager_name']) ?></td>
                <td><?= htmlspecialchars($row['approve_date']) ?></td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <p class="no-record">⚠️ No approved accommodation record found.</p>
      <?php endif; ?>

      <div class="record-back">
        <a href="student_dashboard.php">← Back to Dashboard</a>
      </div>
    </div>

</body>
</html>
