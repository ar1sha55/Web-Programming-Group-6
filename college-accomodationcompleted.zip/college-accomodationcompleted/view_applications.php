<?php
require 'auth.php';
checkLevel(2); // 2 = manager
require 'db_connect.php';

// Fetch applications joined with necessary tables
$result = $conn->query("
    SELECT a.application_id, u.full_name, u.username, c.college_name,
           a.room_type, a.status, a.apply_date, a.semester
    FROM applications a
    JOIN users u ON a.student_id = u.user_id
    JOIN colleges c ON a.college_id = c.college_id
    ORDER BY a.status ASC, a.apply_date DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>View Applications</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="viewmanager.css">
</head>
<body>

<nav class="navbar">
  <div class="navbar-logo"><h1>Student College Accommodation System</h1></div>
  <ul class="navbar-links">
    <li><a href="manager_dashboard.php">Dashboard</a></li>
    <li><a href="edit_profile.php">Profile</a></li>
    <li><a href="view_applications.php">Manage Applications</a></li>
    <li><a href="accommodation_record.php">Accommodation Record</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<div class="content-container">
  <h2 class="page-title">All Student Applications</h2>

  <?php if (isset($_SESSION['app_msg'])): ?>
    <div class="info-alert"><?= $_SESSION['app_msg']; unset($_SESSION['app_msg']); ?></div>
  <?php endif; ?>

  <div class="table-wrapper">
    <table class="app-table">
      <thead>
        <tr>
          <th>Student</th>
          <th>Username</th>
          <th>College</th>
          <th>Applied On</th>
          <th>Room Type</th>
          <th>Semester</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($row['full_name']) ?></td>
          <td><?= htmlspecialchars($row['username']) ?></td>
          <td><?= htmlspecialchars($row['college_name']) ?></td>
          <td><?= htmlspecialchars($row['apply_date']) ?></td>
          <td><?= htmlspecialchars($row['room_type']) ?></td>
          <td><?= htmlspecialchars($row['semester']) ?></td>
          <td><span class="status-<?= $row['status'] ?>"><?= ucfirst(htmlspecialchars($row['status'])) ?></span></td>
          <td>
            <?php if ($row['status'] === 'pending'): ?>
              <form method="post" action="process_application.php" class="inline-form">
                <input type="hidden" name="application_id" value="<?= $row['application_id'] ?>">
                <button type="submit" name="action" value="approve" class="btn-approve">Approve</button>
                <button type="submit" name="action" value="reject" class="btn-reject">Reject</button>
              </form>
            <?php else: ?>
              <span class="dash">–</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
    <div class="back-link">
        <a href="manager_dashboard.php">← Back to Dashboard</a>
    </div>
</div>

</body>
</html>
