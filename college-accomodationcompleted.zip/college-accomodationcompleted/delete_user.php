<?php
require 'auth.php';
checkLevel(1); // Admin only
require 'db_connect.php';
require_once 'log_helper.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['user_message'] = "⚠️ Invalid user ID.";
    header("Location: manage_users.php");
    exit;
}

$user_id = (int) $_GET['id'];

// Prevent self-deletion
if ($user_id === $_SESSION['user_id']) {
    $_SESSION['manage_feedback'] = "❌ You cannot delete your own account.";
    header("Location: manage_users.php");
    exit;
}

// Get username for logging
$stmt = $conn->prepare("SELECT username FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    $_SESSION['user_message'] = "❌ User not found.";
    header("Location: manage_users.php");
    exit;
}
$usernameToDelete = $result->fetch_assoc()['username'];

// Delete user
$stmt = $conn->prepare("DELETE FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);

if ($stmt->execute()) {
    logAction($_SESSION['user_id'], 'delete_user', "Admin {$_SESSION['username']} deleted user $usernameToDelete.");
    $_SESSION['manage_feedback'] = "✅ User '$usernameToDelete' deleted successfully.";
} else {
    $_SESSION['manage_feedback'] = "❌ Failed to delete user: " . $stmt->error;
}

header("Location: manage_users.php");
exit;

