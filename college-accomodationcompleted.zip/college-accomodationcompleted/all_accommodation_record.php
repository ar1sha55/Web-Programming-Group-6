<?php
require 'auth.php';
checkLevel(2); // Only for Accommodation Managers
require 'db_connect.php';

$order = isset($_GET['sort']) && $_GET['sort'] === 'desc' ? 'DESC' : 'ASC';

$query = "
    SELECT ar.*, u.full_name AS student_name, c.college_name, m.full_name AS manager_name
    FROM accommodation_records ar
    JOIN users u ON ar.student_id = u.user_id
    JOIN colleges c ON ar.college_id = c.college_id
    JOIN users m ON ar.approved_by = m.user_id
    ORDER BY student_name $order
";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>All Accommodation Records</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>📋 All Accommodation Records</h2>
<a href="manager_dashboard.php">← Back to Dashboard</a><br><br>

<p>Sort by: 
    <a href="?sort=asc">A–Z</a> | 
    <a href="?sort=desc">Z–A</a>
</p>

<?php if ($result->num_rows > 0): ?>
<table border="1" cellpadding="8" cellspacing="0">
    <tr>
        <th>Semester</th>
        <th>Student Name</th>
        <th>College</th>
        <th>Approved By</th>
        <th>Approval Date</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= htmlspecialchars($row['semester']) ?></td>
        <td><?= htmlspecialchars($row['student_name']) ?></td>
        <td><?= htmlspecialchars($row['college_name']) ?></td>
        <td><?= htmlspecialchars($row['manager_name']) ?></td>
        <td><?= $row['approve_date'] ?></td>
    </tr>
    <?php endwhile; ?>
</table>
<?php else: ?>
<p style="color:#999">⚠️ No accommodation records found.</p>
<?php endif; ?>
</body>
</html>
