// form_validation.js

document.addEventListener("DOMContentLoaded", function () {
    // Validate Full Name (should not be empty or just spaces)
    const fullNameField = document.querySelector('input[name="full_name"]');
    if (fullNameField) {
        fullNameField.addEventListener("blur", function () {
            if (this.value.trim() === '') {
                alert("Full name is required.");
                this.focus();
            }
        });
    }

    // Validate Email format
    const emailField = document.querySelector('input[name="email"]');
    if (emailField) {
        emailField.addEventListener("blur", function () {
            const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (this.value && !regex.test(this.value)) {
                alert("Please enter a valid email address.");
                this.value = '';
                this.focus();
            }
        });
    }

    // Validate Phone Number (only digits, 10–15 characters)
    const phoneField = document.querySelector('input[name="phone_number"]');
    if (phoneField) {
        phoneField.addEventListener("blur", function () {
            const digits = /^[0-9]{10,15}$/;
            if (this.value && !digits.test(this.value)) {
                alert("Phone number must be 10–15 digits.");
                this.value = '';
                this.focus();
            }
        });
    }

});
