<?php
require 'auth.php';
checkLevel(3); // student level
require 'db_connect.php';

$student_id = $_SESSION['user_id'];

// Get latest application
$stmt = $conn->prepare("
    SELECT a.status, a.apply_date, c.college_name, a.remarks, a.room_type
    FROM applications a
    JOIN colleges c ON a.college_id = c.college_id
    WHERE a.student_id = ?
    ORDER BY a.apply_date DESC
    LIMIT 1
");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Application Result</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>Accommodation Application Status</h2>

<?php if ($result->num_rows > 0): 
    $row = $result->fetch_assoc(); ?>
    <p><strong>College:</strong> <?= htmlspecialchars($row['college_name']) ?></p>
    <p><strong>Applied On:</strong> <?= htmlspecialchars($row['apply_date']) ?></p>
    <p><strong>Room Type:</strong> <?= htmlspecialchars($row['room_type']) ?></p>
    <p><strong>Status:</strong> 
        <strong style="color:blue">
            <?= isset($row['status']) ? ucfirst(htmlspecialchars($row['status'])) : 'Unknown' ?>
        </strong>
    </p>
    <p><strong>Remarks:</strong> <?= nl2br(htmlspecialchars($row['remarks'])) ?></p>
<?php else: ?>
    <p>⚠️ No applications found.</p>
<?php endif; ?>

<a href="student_dashboard.php">← Back to Dashboard</a>
</body>
</html>
