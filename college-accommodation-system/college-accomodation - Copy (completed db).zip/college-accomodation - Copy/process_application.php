<?php
require 'auth.php';
checkLevel(2); // 2 = manager
require 'db_connect.php';
require_once 'log_helper.php';

$application_id = intval($_POST['application_id']);
$action = $_POST['action'];
$manager_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Fetch application details (only pending)
$stmt = $conn->prepare("
    SELECT a.student_id, a.college_id, c.available_slots 
    FROM applications a
    JOIN colleges c ON a.college_id = c.college_id
    WHERE a.application_id = ? AND a.status = 'pending'
");
$stmt->bind_param("i", $application_id);
$stmt->execute();
$app = $stmt->get_result()->fetch_assoc();

if (!$app) {
    die("⚠️ Application not found or already processed.");
}

$student_id = $app['student_id'];
$college_id = $app['college_id'];
$available = $app['available_slots'];

if ($action === 'approve') {
    if ($available <= 0) {
        die("❌ No available slots in the selected college.");
    }

    // 1. Update application status
    $stmt = $conn->prepare("UPDATE applications SET status = 'approved', remarks = 'Approved by manager' WHERE application_id = ?");
    $stmt->bind_param("i", $application_id);
    $stmt->execute();

    // 2. Decrease room availability
    $stmt = $conn->prepare("UPDATE rooms SET available_rooms = available_rooms - 1 
                            WHERE college_id = ? AND room_type = (
                                SELECT room_type FROM applications WHERE application_id = ?
                            )");
    $stmt->bind_param("ii", $college_id, $application_id);
    $stmt->execute();

    // 3. Sync college available_slots with total available_rooms
    $stmt = $conn->prepare("SELECT SUM(available_rooms) FROM rooms WHERE college_id = ?");
    $stmt->bind_param("i", $college_id);
    $stmt->execute();
    $total = $stmt->get_result()->fetch_row()[0] ?? 0;

    $update = $conn->prepare("UPDATE colleges SET available_slots = ? WHERE college_id = ?");
    $update->bind_param("ii", $total, $college_id);
    $update->execute();

    // 4. Record approval
    $date = date('Y-m-d');
    $stmt = $conn->prepare("INSERT INTO accommodation_records (student_id, college_id, approved_by, approve_date) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiis", $student_id, $college_id, $manager_id, $date);
    $stmt->execute();

    // 5. Log
    logAction($manager_id, 'approve', "Manager $username approved application ID $application_id.");

} elseif ($action === 'reject') {
    // Reject the application
    $stmt = $conn->prepare("UPDATE applications SET status = 'rejected', remarks = 'Rejected by manager' WHERE application_id = ?");
    $stmt->bind_param("i", $application_id);
    $stmt->execute();

    // Log
    logAction($manager_id, 'reject', "Manager $username rejected application ID $application_id.");

} else {
    die("❌ Invalid action.");
}

// Return to application list
header("Location: view_applications.php");
exit;
?>
