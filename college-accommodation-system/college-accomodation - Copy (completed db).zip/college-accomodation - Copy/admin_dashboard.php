<?php
require 'auth.php';
checkLevel(1); // 1 = admin
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>👩‍💼 Admin Dashboard</h2>


<ul>
    <li><a href="manage_users.php">👥 Manage Users</a></li>
    <li><a href="view_logs.php">📜 View System Logs</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
</ul>

</body>
</html>
