<?php
require 'auth.php';
checkLevel(1); // admin only
require 'db_connect.php';

if (!isset($_GET['id'])) {
    die("❌ User ID is missing.");
}

$user_id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("❌ User not found.");
}
$user = $result->fetch_assoc();

// Fetch from students/managers table if applicable
$extra = [];
if ($user['user_level'] == 3) { // student
    $stmt = $conn->prepare("SELECT * FROM students WHERE student_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $extra = $stmt->get_result()->fetch_assoc();
} elseif ($user['user_level'] == 2) { // manager
    $stmt = $conn->prepare("SELECT * FROM managers WHERE manager_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $extra = $stmt->get_result()->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>Edit User</h2>

<form method="post" action="update_user.php">
    <input type="hidden" name="user_id" value="<?= $user['user_id'] ?>">

    Full Name: <input type="text" name="full_name" value="<?= htmlspecialchars($user['full_name']) ?>" required><br>
    Username: <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required><br>
    Password: <input type="text" name="password" value="<?= htmlspecialchars($user['password']) ?>" required><br>
    Email: <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>"><br>

    User Level:
    <select name="user_level" required>
        <option value="1" <?= $user['user_level'] == 1 ? 'selected' : '' ?>>Admin</option>
        <option value="2" <?= $user['user_level'] == 2 ? 'selected' : '' ?>>Manager</option>
        <option value="3" <?= $user['user_level'] == 3 ? 'selected' : '' ?>>Student</option>
    </select><br><br>

    <?php if ($user['user_level'] == 3 && $extra): ?>
        <h4>Student Info</h4>
        Matric Number: <input type="text" name="matric_number" value="<?= htmlspecialchars($extra['matric_number']) ?>" readonly><br>
        Program: <input type="text" name="program" value="<?= htmlspecialchars($extra['program']) ?>"><br>
        Year: <input type="number" name="year" value="<?= htmlspecialchars($extra['year']) ?>"><br><br>
    <?php elseif ($user['user_level'] == 2 && $extra): ?>
        <h4>Manager Info</h4>
        Department: <input type="text" name="department" value="<?= htmlspecialchars($extra['department']) ?>"><br>
        Office Phone: <input type="text" name="office_phone" value="<?= htmlspecialchars($extra['office_phone']) ?>"><br><br>
    <?php endif; ?>

    <input type="submit" value="Update User">
</form>

<a href="manage_users.php">← Back to User Management</a>
</body>
</html>
