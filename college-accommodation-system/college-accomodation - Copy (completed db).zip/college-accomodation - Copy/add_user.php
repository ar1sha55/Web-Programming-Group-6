<?php
require 'auth.php';
checkLevel(1); // admin
require 'db_connect.php';

$full_name   = trim($_POST['full_name']);
$username    = trim($_POST['username']);
$password    = trim($_POST['password']); // plain-text for now
$email       = trim($_POST['email']);
$user_level  = intval($_POST['user_level']); // 1=admin, 2=manager, 3=student

// Basic validation
if (!$full_name || !$username || !$password || !$user_level) {
    die("⚠️ All fields except email are required.");
}
if (!in_array($user_level, [1, 2, 3])) {
    die("❌ Invalid user level.");
}

// Insert new user
$stmt = $conn->prepare("INSERT INTO users (full_name, username, password, email, user_level) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("ssssi", $full_name, $username, $password, $email, $user_level);

if ($stmt->execute()) {
    // Log action
    require_once 'log_helper.php';
    logAction($_SESSION['user_id'], 'add_user', "Admin {$_SESSION['username']} added user $username (level $user_level).");

    header("Location: manage_users.php");
    exit;
} else {
    echo "❌ Failed to add user: " . $stmt->error;
}
