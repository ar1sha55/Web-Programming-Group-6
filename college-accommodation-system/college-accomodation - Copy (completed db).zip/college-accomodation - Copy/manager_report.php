<?php
require 'auth.php';
checkRole('manager');
require 'db_connect.php';

$sql = "SELECT a.application_id, u.full_name, c.college_name, a.status, a.preferred_start_date, a.apply_date
        FROM applications a
        JOIN users u ON a.student_id = u.user_id
        JOIN colleges c ON a.college_id = c.college_id
        ORDER BY u.full_name ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manager Application Report</title>
    <link rel="stylesheet" href="style.css">
    <script src="table_filter.js" defer></script>
</head>
<body>
<h2>📊 Application Report</h2>
<a href="manager_page.php">⬅ Back to Dashboard</a><br><br>

<input type="text" id="searchInput" placeholder="🔍 Search student or college..." onkeyup="filterTable()"><br><br>

<table id="reportTable" border="1" cellpadding="8">
    <thead>
    <tr>
        <th>Student</th>
        <th>College</th>
        <th>Status</th>
        <th>Apply Date</th>
        <th>Preferred Start</th>
    </tr>
    </thead>
    <tbody>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['full_name']) ?></td>
            <td><?= htmlspecialchars($row['college_name']) ?></td>
            <td><?= ucfirst($row['status']) ?></td>
            <td><?= htmlspecialchars($row['apply_date']) ?></td>
            <td><?= htmlspecialchars($row['preferred_start_date']) ?></td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>

</body>
</html>
