// form_validation.js

document.addEventListener("DOMContentLoaded", function () {

    // Preferred Start Date: Must not be in the past
    const preferredDate = document.querySelector('input[name="preferred_start_date"]');
    if (preferredDate) {
        preferredDate.addEventListener("change", function () {
            const selected = new Date(this.value);
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            if (selected < today) {
                alert("Preferred start date cannot be in the past.");
                this.value = '';
            }
        });
    }

    // Email format validation
    const emailField = document.querySelector('input[type="email"]');
    if (emailField) {
        emailField.addEventListener("blur", function () {
            const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (this.value && !regex.test(this.value)) {
                alert("Please enter a valid email address.");
                this.value = '';
            }
        });
    }

    // Phone number: 10–15 digits only
    const phoneField = document.querySelector('input[name="phone_number"]');
    if (phoneField) {
        phoneField.addEventListener("blur", function () {
            const digits = /^[0-9]{10,15}$/;
            if (this.value && !digits.test(this.value)) {
                alert("Phone number must be 10–15 digits.");
                this.value = '';
            }
        });
    }

    // Password: Minimum 5 characters
    const passwordField = document.querySelector('input[name="password"]');
    if (passwordField) {
        passwordField.addEventListener("blur", function () {
            if (this.value && this.value.length < 5) {
                alert("Password must be at least 5 characters long.");
                this.value = '';
            }
        });
    }

});
