<?php
require 'auth.php';
require 'db_connect.php';

$user_id = $_SESSION['user_id'];
$user_level = $_SESSION['user_level'];

// Fetch common info
$stmt = $conn->prepare("SELECT full_name, email, phone_number, address FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$userResult = $stmt->get_result();
if ($userResult->num_rows === 0) {
    die("❌ User not found.");
}
$user = $userResult->fetch_assoc();

// Fetch role-specific info
$extra = [];
if ($user_level === 3) {
    $stmt = $conn->prepare("SELECT matric_number, program, year FROM students WHERE student_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $extra = $stmt->get_result()->fetch_assoc();
} elseif ($user_level === 2) {
    $stmt = $conn->prepare("SELECT department, office_phone FROM managers WHERE manager_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $extra = $stmt->get_result()->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit My Profile</title>
    <link rel="stylesheet" href="style.css">
    <script src="form_validation.js" defer></script>
</head>
<body>
<h2>Edit My Profile</h2>

<form method="post" action="update_profile.php">
    <h3>🔒 Account Info</h3>
    Full Name: <input type="text" name="full_name" value="<?= htmlspecialchars($user['full_name']) ?>" required><br>
    Email: <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>"><br>
    Phone: <input type="text" name="phone_number" value="<?= htmlspecialchars($user['phone_number']) ?>"><br>
    Address: <textarea name="address"><?= htmlspecialchars($user['address']) ?></textarea><br><br>

    <?php if ($user_level === 3): ?>
        <h3>🎓 Student Info</h3>
        Matric Number: <input type="text" name="matric_number" value="<?= htmlspecialchars($extra['matric_number']) ?>" readonly><br>
        Program: <input type="text" name="program" value="<?= htmlspecialchars($extra['program']) ?>"><br>
        Year: <input type="number" name="year" value="<?= htmlspecialchars($extra['year']) ?>"><br><br>
    <?php elseif ($user_level === 2): ?>
        <h3>🏢 Manager Info</h3>
        Department: <input type="text" name="department" value="<?= htmlspecialchars($extra['department']) ?>"><br>
        Office Phone: <input type="text" name="office_phone" value="<?= htmlspecialchars($extra['office_phone']) ?>"><br><br>
    <?php endif; ?>

    <input type="submit" value="Update My Profile">
</form>

<?php
$backLink = ($user_level === 2) ? 'manager_dashboard.php' : 'student_dashboard.php';
?>
<a href="<?= $backLink ?>">← Back to Dashboard</a>
</body>
</html>
