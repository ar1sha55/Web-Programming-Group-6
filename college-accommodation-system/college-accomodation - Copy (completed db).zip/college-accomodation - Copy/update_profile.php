<?php
require 'auth.php';
require 'db_connect.php';
require_once 'log_helper.php';

$user_id      = $_SESSION['user_id'];
$user_level   = $_SESSION['user_level'];
$username     = $_SESSION['username'];

$full_name    = trim($_POST['full_name']);
$email        = trim($_POST['email']);
$phone_number = trim($_POST['phone_number']);
$address      = trim($_POST['address']);

// Basic validation
if (!$full_name) {
    die("⚠️ Full name is required.");
}

// Update users table
$stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, phone_number = ?, address = ? WHERE user_id = ?");
$stmt->bind_param("ssssi", $full_name, $email, $phone_number, $address, $user_id);
if (!$stmt->execute()) {
    die("❌ Failed to update main profile: " . $stmt->error);
}

// Update extra info based on user level
if ($user_level === 3) {
    $program = trim($_POST['program']);
    $year = (int)$_POST['year'];

    $stmt = $conn->prepare("UPDATE students SET program = ?, year = ? WHERE student_id = ?");
    $stmt->bind_param("sii", $program, $year, $user_id);
    if (!$stmt->execute()) {
        die("❌ Failed to update student info: " . $stmt->error);
    }

} elseif ($user_level === 2) {
    $department = trim($_POST['department']);
    $office_phone = trim($_POST['office_phone']);

    $stmt = $conn->prepare("UPDATE managers SET department = ?, office_phone = ? WHERE manager_id = ?");
    $stmt->bind_param("ssi", $department, $office_phone, $user_id);
    if (!$stmt->execute()) {
        die("❌ Failed to update manager info: " . $stmt->error);
    }
}

// Log activity
logAction($user_id, 'edit_profile', "User $username updated profile.");

// Redirect
if ($user_level === 3) {
    header("Location: student_dashboard.php");
} elseif ($user_level === 2) {
    header("Location: manager_dashboard.php");
} else {
    header("Location: index.php");
}
exit;
