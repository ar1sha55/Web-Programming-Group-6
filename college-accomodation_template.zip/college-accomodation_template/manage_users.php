<?php
require 'auth.php';
checkLevel(1); // 1 = admin
require 'db_connect.php';

// Get all users
$result = $conn->query("SELECT * FROM users");

// Helper to display user level as role name
function getRoleName($level) {
    switch ($level) {
        case 1: return "Admin";
        case 2: return "Manager";
        case 3: return "Student";
        default: return "Unknown";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Users</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>Admin: Manage Users</h2>

<!-- Add New User Form -->
<h3>Add New User</h3>
<form method="post" action="add_user.php">
    Full Name: <input type="text" name="full_name" required><br>
    Username: <input type="text" name="username" required><br>
    Password: <input type="text" name="password" required><br>
    Email: <input type="email" name="email"><br>
    User Level:
    <select name="user_level" required>
        <option value="1">Admin</option>
        <option value="2">Manager</option>
        <option value="3">Student</option>
    </select><br><br>
    <input type="submit" value="Add User">
</form>

<hr>

<!-- User Table -->
<h3>All Users</h3>
<table border="1" cellpadding="8">
    <tr>
        <th>ID</th><th>Full Name</th><th>Username</th><th>Email</th><th>User Level</th><th>Actions</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= htmlspecialchars($row['user_id']) ?></td>
        <td><?= htmlspecialchars($row['full_name']) ?></td>
        <td><?= htmlspecialchars($row['username']) ?></td>
        <td><?= htmlspecialchars($row['email']) ?></td>
        <td><?= getRoleName($row['user_level']) ?></td>
        <td>
            <a href="edit_user.php?id=<?= $row['user_id'] ?>">Edit</a> |
            <a href="delete_user.php?id=<?= $row['user_id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
