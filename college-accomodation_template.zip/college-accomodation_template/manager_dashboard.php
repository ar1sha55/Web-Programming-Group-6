<?php
require 'auth.php';
checkLevel(2); // 2 = manager
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manager Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>Welcome, <?= htmlspecialchars($_SESSION['username']) ?> (Manager)</h2>

<ul>
    <li><a href="view_applications.php">📋 View & Manage Applications</a></li>
    <li><a href="edit_profile.php">👤 Edit My Profile</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
</ul>

</body>
</html>
