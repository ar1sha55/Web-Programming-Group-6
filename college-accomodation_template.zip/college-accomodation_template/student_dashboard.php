<?php
require 'auth.php';
checkLevel(3); // 3 = student
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="style.css">
    
</head>
<body>
<h2>Welcome, <?= htmlspecialchars($_SESSION['username']) ?> (Student)</h2>

<ul>
    <li><a href="apply_accommodation.php">📝 Apply for Accommodation</a></li>
    <li><a href="view_my_application.php">📄 View My Application</a></li>
    <li><a href="edit_profile.php">👤 Edit My Profile</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
</ul>

</body>
</html>
