<?php
require 'auth.php';
checkLevel(3); // 3 = student
require 'db_connect.php';

// Fetch colleges with available slots
$result = $conn->query("SELECT college_id, college_name FROM colleges WHERE available_slots > 0");
$colleges = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Apply for Accommodation</title>
    <link rel="stylesheet" href="style.css">
  
    
</head>
<body>
<h2>Apply for College Accommodation</h2>

<?php
if (isset($_SESSION['application_success'])):
?>
    <div style="padding: 10px; background-color: #e0f7fa; border: 1px solid #4caf50; color: #00796b; margin-bottom: 15px;">
        <?= $_SESSION['application_success'] ?>
    </div>
<?php
    unset($_SESSION['application_success']);
endif;
?>

<form method="post" action="submit_application.php">
    <label for="college">College:</label>
    <select name="college_id" id="college" required>
        <option value="">-- Select College --</option>
        <?php foreach ($colleges as $college): ?>
            <option value="<?= htmlspecialchars($college['college_id']) ?>">
                <?= htmlspecialchars($college['college_name']) ?>
            </option>
        <?php endforeach; ?>
    </select><br><br>

    <label for="start_date">Preferred Start Date:</label>
    <input type="date" name="preferred_start_date" id="start_date" required><br><br>

    <input type="submit" value="Submit Application">
</form>

<a href="student_dashboard.php">← Back to Dashboard</a>

<script src="form_validation.js" defer></script>
</body>
</html>
