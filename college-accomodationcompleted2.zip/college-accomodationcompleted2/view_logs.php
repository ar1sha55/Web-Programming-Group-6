<?php
require_once 'auth.php';
checkLevel(1); // admin only
require_once 'db_connect.php';

$query = "
    SELECT hl.*, u.username 
    FROM history_log hl
    LEFT JOIN users u ON hl.user_id = u.user_id
    ORDER BY hl.action_time DESC
";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Activity Logs</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="logs.css">
</head>
<body>

  <!-- Navbar -->
  <nav class="navbar">
    <div class="navbar-logo">
      <h1>Student College Accommodation System</h1>
    </div>
    <ul class="navbar-links">
      <li><a href="manager_dashboard.php">Dashboard</a></li>
      <li><a href="manage_users.php">Manage Users</a></li>
      <li><a href="view_logs.php">System Logs</a></li>
      <li><a href="manage_semester.php">Manage Semester</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>

  <!-- Content Wrapper -->
  <div class="logs-container">
    <div class="logs-header">
        <h2 class="logs-title">System Activity Logs</h2>
        <div class="back-link">
          <a href="admin_dashboard.php">← Back to Dashboard</a>
        </div>
        
    </div>

    <div class="logs-table-wrapper">
      <table class="logs-table">
        <thead>
          <tr>
            <th>Log ID</th>
            <th>User</th>
            <th>Action Type</th>
            <th>Description</th>
            <th>Timestamp</th>
          </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= $row['log_id'] ?></td>
            <td><?= htmlspecialchars($row['username'] ?? 'Unknown') ?></td>
            <td><?= $row['action_type'] ?></td>
            <td><?= htmlspecialchars($row['description']) ?></td>
            <td><?= $row['action_time'] ?></td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>

</body>
</html>


