<?php
require 'auth.php';
checkLevel(1);
require 'db_connect.php';

$semester_options = [
    '2024/2025 Semester 1',
    '2024/2025 Semester 2',
    '2025/2026 Semester 1',
    '2025/2026 Semester 2',
    '2026/2027 Semester 1',
    '2026/2027 Semester 2'
];

// Fetch current semester
$current = 'Not Set';
$result = $conn->query("SELECT current_semester FROM semester_config LIMIT 1");
if ($row = $result->fetch_assoc()) {
    $current = $row['current_semester'];
}

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_semester'])) {
    $new_semester = trim($_POST['new_semester']);

    if (!in_array($new_semester, $semester_options)) {
        $_SESSION['sem_msg'] = "❌ Invalid semester selected.";
    } elseif ($new_semester === $current) {
        $_SESSION['sem_msg'] = "⚠️ No changes made. Selected semester is already active.";
    } else {
        $stmt = $conn->prepare("UPDATE semester_config SET current_semester = ? LIMIT 1");
        $stmt->bind_param("s", $new_semester);
        $stmt->execute();
        $_SESSION['sem_msg'] = "✅ Semester updated to: $new_semester";
    }

    header("Location: semester_config.php");
    exit;
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Semester Configuration</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>📅 Current Semester Configuration</h2>
<a href="admin_dashboard.php">← Back to Dashboard</a><br><br>

<?php if (isset($_SESSION['sem_msg'])): ?>
    <div style="padding:10px; background:#e0f2f1; border-left:4px solid #00796b; margin-bottom:15px;">
        <?= $_SESSION['sem_msg']; unset($_SESSION['sem_msg']); ?>
    </div>
<?php endif; ?>

<p><strong>Current Semester:</strong> <?= htmlspecialchars($current) ?></p>

<form method="POST">
    <label for="new_semester">Select Semester:</label><br>
    <select name="new_semester" id="new_semester" required>
        <option value="">-- Select Semester --</option>
        <?php foreach ($semester_options as $sem): ?>
            <option value="<?= $sem ?>" <?= $sem === $current ? 'selected' : '' ?>><?= $sem ?></option>
        <?php endforeach; ?>
    </select>
    <button type="submit">Update</button>
</form>
</body>
</html>
