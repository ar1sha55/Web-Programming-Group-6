<?php 
session_start(); 

// Redirect if already logged in
// If the user is already logged in (has a session), redirect them to the appropriate dashboard based on their user level.
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['user_level'] === 1) {
        // Admin - Redirect to the admin dashboard
        header("Location: admin_dashboard.php");
        exit;
    } elseif ($_SESSION['user_level'] === 2) {
        // Manager - Redirect to the manager dashboard
        header("Location: manager_dashboard.php");
        exit;
    } elseif ($_SESSION['user_level'] === 3) {
        // Student - Redirect to the student dashboard
        header("Location: student_dashboard.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <title>Login | Student Accommodation</title>
   <link rel="stylesheet" href="css/style.css" />
   <link rel="stylesheet" href="css/index.css" />
</head>
<body>
   <div class="login-wrapper">
    
     <div class="system-name">
       <h1>Student College Accommodation System</h1>
     </div>

     <!-- Login Form Container -->
     <div class="login-container">
       <h2>👤 User Login</h2>

       <!-- Display error message if login fails -->
       <?php if (isset($_SESSION['login_error'])): ?>
         <!-- Displaying login error message -->
         <div class="alert error">
           <?= $_SESSION['login_error']; ?>
         </div>
         <?php unset($_SESSION['login_error']); ?>
       <?php endif; ?>

       <!-- Login Form -->
       <form method="post" action="login_process.php">
         <!-- Username input field -->
         <label for="username">Username</label>
         <input type="text" id="username" name="username" placeholder="Your username"/>

         <!-- Password input field -->
         <label for="password">Password</label>
         <input type="password" id="password" name="password" placeholder="Your password"/>

         <!-- Submit button to log in -->
         <input type="submit" value="Login" class="login-button" />
       </form>
     </div>
   </div>

<!-- For Validation Purpose -->
<!-- JavaScript for form validation -->
<script src="js/form_validation.js" defer></script>

</body>
</html>
