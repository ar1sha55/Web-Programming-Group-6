<?php
// Include authentication and ensure the user is an admin (Level 1)
require 'auth.php';
checkLevel(1); 

// Include the database connection
require 'db_connect.php';

// Initialize an array to hold user data
$users = [];

// SQL query to fetch user information, including their role
$sql = "SELECT user_id, full_name AS name, email,  
        CASE 
            WHEN user_level = 1 THEN 'Admin'
            WHEN user_level = 2 THEN 'Manager'
            WHEN user_level = 3 THEN 'Student'
            ELSE 'Unknown'
        END AS role
        FROM users";

// Execute the query
$result = $conn->query($sql);

// Check if the query returned results and loop through them to populate the $users array
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row; // Add each user to the array
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Users</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Link to main stylesheet -->
    <link rel="stylesheet" href="css/manage_user.css"> <!-- Link to manage user-specific stylesheet -->
</head>
<body>

<!-- Navbar -->
<nav class="navbar">
    <div class="navbar-logo">
        <h1>Student College Accommodation System</h1> <!-- Logo of the system -->
    </div>
    <ul class="navbar-links">
        <!-- Navigation links for the Admin -->
        <li><a href="manager_dashboard.php">Dashboard</a></li>
        <li><a href="manage_users.php">Manage Users</a></li>
        <li><a href="view_logs.php">System Logs</a></li>
        <li><a href="manage_semester.php">Manage Semester</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>

<!-- Manage Users Section -->
<div class="manage-section">
    <div class="manage-container">
        <h2 class="manage-title">Manage Users</h2>

        <!-- Display session feedback messages (e.g., success, error) -->
        <?php if (isset($_SESSION['manage_feedback'])): ?>
            <div class="manage-alert">
                <?= $_SESSION['manage_feedback'] ?> <!-- Show feedback message -->
            </div>
        <?php unset($_SESSION['manage_feedback']); endif; ?>

        <!-- Button to add a new user -->
        <div class="user-actions">
            <a href="add_user.php" class="add-btn">+ Add New User</a>
        </div>

        <!-- User table to display all users -->
        <table class="user-table">
            <thead>
                <tr>
                    <th>ID</th> <!-- Column for User ID -->
                    <th>Full Name</th> <!-- Column for User's Full Name -->
                    <th>Email</th> <!-- Column for User's Email -->
                    <th>Role</th> <!-- Column for User's Role -->
                    <th>Actions</th> <!-- Column for Action buttons (Edit, Delete) -->
                </tr>
            </thead>
            <tbody>
                <!-- Loop through the users array to display each user's information -->
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= htmlspecialchars($user['user_id']) ?></td> <!-- Display User ID -->
                    <td><?= htmlspecialchars($user['name']) ?></td> <!-- Display User Name -->
                    <td><?= htmlspecialchars($user['email']) ?></td> <!-- Display User Email -->
                    <td><?= htmlspecialchars($user['role']) ?></td> <!-- Display User Role -->
                    <td>
                        <!-- Edit button with link to edit the user -->
                        <a href="edit_user.php?id=<?= $user['user_id'] ?>" class="edit-btn">Edit</a>
                        <!-- Delete button with confirmation dialog before deletion -->
                        <a href="delete_user.php?id=<?= $user['user_id'] ?>" class="delete-btn" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <!-- Back link to navigate to the admin dashboard -->
        <div class="back-link">
            <a href="manager_dashboard.php">← Back to Dashboard</a>
        </div>
    </div>
</div>

</body>
</html>
