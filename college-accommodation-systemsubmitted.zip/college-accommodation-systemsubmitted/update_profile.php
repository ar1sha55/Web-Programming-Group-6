<?php
require 'auth.php'; // Ensures the user is authenticated and logged in
require 'db_connect.php'; // Establish a connection to the database
require_once 'log_helper.php'; // Includes the logAction function to log activities

// Get the user data from session
$user_id = $_SESSION['user_id']; // Get the logged-in user's ID
$user_level = $_SESSION['user_level']; // Get the user's role level (admin, manager, student)
$username = $_SESSION['username']; // Get the logged-in username

// Get the form data from POST request
$full_name = trim($_POST['full_name']); // Trim the full name field for any unwanted spaces
$email = trim($_POST['email']); // Trim the email field
$phone_number = trim($_POST['phone_number']); // Trim the phone number field
$address = trim($_POST['address']); // Trim the address field

// Validation check to ensure full name is provided
if (!$full_name) {
    die("⚠️ Full name is required."); // If no full name is provided, show an error and stop the script
}

// Update the users table with the new data
$stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, phone_number = ?, address = ? WHERE user_id = ?");
$stmt->bind_param("ssssi", $full_name, $email, $phone_number, $address, $user_id); // Bind the parameters to avoid SQL injection

// Execute the query and check for errors
if (!$stmt->execute()) {
    die("❌ Failed to update main profile: " . $stmt->error); // If the update fails, display an error
}

// Log the profile update action using the log helper function
logAction($user_id, 'edit_profile', "User $username updated profile.");

// Set a success message in the session for inline display
$_SESSION['profile_update_success'] = "Profile updated successfully!";

// Redirect the user back to the profile edit page
header("Location: edit_profile.php");
