<?php
// Start the session and include necessary files
require 'auth.php';
checkLevel(1); // Only admin is allowed to access this page
require 'db_connect.php';

// Define the list of valid semester options
$semester_options = [
    '2024/2025 Semester 1',
    '2024/2025 Semester 2',
    '2025/2026 Semester 1',
    '2025/2026 Semester 2',
    '2026/2027 Semester 1',
    '2026/2027 Semester 2'
];

// Fetch the current active semester from the database
$current = 'Not Set'; // Default value if no semester is set
$result = $conn->query("SELECT current_semester FROM semester_config LIMIT 1");
if ($row = $result->fetch_assoc()) {
    $current = $row['current_semester']; // Store the current semester value
}

// Handle form submission for updating the semester
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_semester'])) {
    $new_semester = trim($_POST['new_semester']); // Get the new semester selected by the admin

    // Check if the selected semester is valid
    if (!in_array($new_semester, $semester_options)) {
        $_SESSION['sem_msg'] = "❌ Invalid semester selected."; // Show error if the selected semester is invalid
    } elseif ($new_semester === $current) {
        // Check if the selected semester is the same as the current active semester
        $_SESSION['sem_msg'] = "⚠️ No changes made. Selected semester is already active.";
    } else {
        // Update the semester in the database if it's a valid new semester
        $stmt = $conn->prepare("UPDATE semester_config SET current_semester = ? LIMIT 1");
        $stmt->bind_param("s", $new_semester); // Bind the new semester value
        $stmt->execute(); // Execute the update query
        $_SESSION['sem_msg'] = "✅ Semester updated to: $new_semester"; // Success message
    }

    // Redirect to manage_semester.php page after processing the form
    header("Location: manage_semester.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1.0" />
  <title>Semester Configuration</title>
  <link rel="stylesheet" href="css/style.css" />
  <link rel="stylesheet" href="css/manage_semester.css" />
</head>
<body>

  <!-- Navbar -->
  <nav class="navbar">
    <div class="navbar-logo">
      <h1>Student College Accommodation System</h1>
    </div>
    <ul class="navbar-links">
      <!-- Navigation menu for Admin -->
      <li><a href="manager_dashboard.php">Dashboard</a></li>
      <li><a href="manage_users.php">Manage Users</a></li>
      <li><a href="view_logs.php">System Logs</a></li>
      <li><a href="manage_semester.php">Manage Semester</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>

  <!-- Main content for semester management -->
  <div class="semester-container">
    <h2 class="semester-title">Manage Semester</h2>

    <!-- Display session message if there is any -->
    <?php if (isset($_SESSION['sem_msg'])): ?>
      <div class="semester-alert"><?= $_SESSION['sem_msg']; unset($_SESSION['sem_msg']); ?></div>
    <?php endif; ?>

    <!-- Display current active semester -->
    <div class="semester-current">
      <strong>Current Semester:</strong> <span class="semester-value"><?= htmlspecialchars($current) ?></span>
    </div>

    <!-- Form to select and update semester -->
    <form method="POST" class="semester-form">
      <label for="new_semester">Select Semester:</label>
      <select name="new_semester" id="new_semester" required>
        <option value="">-- Select Semester --</option>
        <!-- Loop through semester options and display them -->
        <?php foreach ($semester_options as $sem): ?>
          <option value="<?= $sem ?>" <?= $sem === $current ? 'selected' : '' ?>><?= $sem ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="semester-button">Update Semester</button>
    </form>

    <!-- Link to go back to dashboard -->
    <div class="semester-back">
      <a href="admin_dashboard.php">← Back to Dashboard</a>
    </div>
  </div>

</body>
</html>
