<?php
require 'auth.php'; // Include authentication to check if the user is logged in
checkLevel(1); // Ensure that only an admin (level 1) can access this page
require 'db_connect.php'; // Include the database connection
require_once 'log_helper.php'; // Include the log helper for logging actions

// Check if the 'id' parameter is set in the URL and is a valid number
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['user_message'] = "⚠️ Invalid user ID."; // Set an error message if the ID is invalid
    header("Location: manage_users.php"); // Redirect back to the manage users page
    exit;
}

// Sanitize the user ID from the URL to ensure it's an integer
$user_id = (int) $_GET['id'];

// Prevent the admin from deleting their own account
if ($user_id === $_SESSION['user_id']) {
    $_SESSION['manage_feedback'] = "❌ You cannot delete your own account."; // Set a feedback message for self-deletion attempt
    header("Location: manage_users.php"); // Redirect to the manage users page
    exit;
}

// Get the username of the user to be deleted for logging purposes
$stmt = $conn->prepare("SELECT username FROM users WHERE user_id = ?"); 
$stmt->bind_param("i", $user_id); // Bind the user_id parameter to the prepared statement
$stmt->execute();
$result = $stmt->get_result(); // Execute the query and get the result

// If the user is not found, set an error message and redirect
if ($result->num_rows === 0) {
    $_SESSION['user_message'] = "❌ User not found."; // Set error message
    header("Location: manage_users.php"); // Redirect to manage users page
    exit;
}

// Get the username to be deleted for logging
$usernameToDelete = $result->fetch_assoc()['username'];

// Prepare and execute the query to delete the user
$stmt = $conn->prepare("DELETE FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id); // Bind the user_id parameter

// Execute the delete query
if ($stmt->execute()) {
    // Log the action of deleting the user
    logAction($_SESSION['user_id'], 'delete_user', "Admin {$_SESSION['username']} deleted user $usernameToDelete.");
    $_SESSION['manage_feedback'] = "✅ User '$usernameToDelete' deleted successfully."; // Success message
} else {
    // If the deletion fails, set an error message
    $_SESSION['manage_feedback'] = "❌ Failed to delete user: " . $stmt->error;
}

// Redirect back to the manage users page
header("Location: manage_users.php");
exit;

