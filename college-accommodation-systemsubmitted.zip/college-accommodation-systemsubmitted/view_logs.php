<?php
require_once 'auth.php';  // Ensure the user is logged in and authenticated
checkLevel(1); // Check if the user has admin privileges (level 1)
require_once 'db_connect.php';  // Include the database connection

// Fetch all system activity logs with relevant user information
$query = "
    SELECT hl.*, u.username 
    FROM history_log hl
    LEFT JOIN users u ON hl.user_id = u.user_id
    ORDER BY hl.action_time DESC  // Sort logs by the timestamp in descending order
";
$result = $conn->query($query);  // Execute the query
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Activity Logs</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/style.css">  <!-- Include main styles -->
  <link rel="stylesheet" href="css/logs.css">   <!-- Include specific styles for logs page -->
</head>
<body>

  <!-- Navbar: Navigation for admin to manage different parts of the system -->
  <nav class="navbar">
    <div class="navbar-logo">
      <h1>Student College Accommodation System</h1>
    </div>
    <ul class="navbar-links">
      <li><a href="manager_dashboard.php">Dashboard</a></li>
      <li><a href="manage_users.php">Manage Users</a></li>
      <li><a href="view_logs.php">System Logs</a></li>
      <li><a href="manage_semester.php">Manage Semester</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>

  <!-- Main content of the Activity Logs page -->
  <div class="logs-container">
    <div class="logs-header">
        <h2 class="logs-title">System Activity Logs</h2>
        <div class="back-link">
          <!-- Link to go back to the Admin Dashboard -->
          <a href="admin_dashboard.php">← Back to Dashboard</a>
        </div>
    </div>

    <!-- Table to display the logs fetched from the database -->
    <div class="logs-table-wrapper">
      <table class="logs-table">
        <thead>
          <tr>
            <th>Log ID</th>  <!-- Log identifier -->
            <th>User</th>    <!-- Username of the user who performed the action -->
            <th>Action Type</th>  <!-- Type of action performed (e.g., login, add user, delete user) -->
            <th>Description</th>  <!-- Detailed description of the action -->
            <th>Timestamp</th>  <!-- Time when the action occurred -->
          </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= $row['log_id'] ?></td>  <!-- Log ID -->
            <td><?= htmlspecialchars($row['username'] ?? 'Unknown') ?></td>  <!-- Display username, default to 'Unknown' if not available -->
            <td><?= $row['action_type'] ?></td>  <!-- Action type (e.g., login, edit user) -->
            <td><?= htmlspecialchars($row['description']) ?></td>  <!-- Description of the action -->
            <td><?= $row['action_time'] ?></td>  <!-- Timestamp of the action -->
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>

</body>
</html>
