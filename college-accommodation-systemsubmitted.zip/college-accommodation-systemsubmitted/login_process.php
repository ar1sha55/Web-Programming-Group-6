<?php
// Start the session
session_start();

// Include the necessary files for database connection and logging
require 'db_connect.php';
require_once 'log_helper.php';

// Retrieve the login credentials entered by the user
$username = $_POST['username']; // The username entered by the user
$password = $_POST['password']; // The password entered by the user

// Prepare and execute a query to find the user based on the entered username
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
$stmt->bind_param("s", $username); // Bind the username parameter
$stmt->execute(); // Execute the query
$result = $stmt->get_result(); // Get the result of the query

// Check if a user is found with the provided username
if ($user = $result->fetch_assoc()) {
    // Compare the provided password with the stored password (plain text comparison)
    if ($user['password'] === $password) {
        // If login is successful, store the user data in session variables
        $_SESSION['user_id'] = $user['user_id']; // Store user ID in session
        $_SESSION['username'] = $user['username']; // Store username in session
        $_SESSION['user_level'] = (int)$user['user_level']; // Store user level (admin, manager, student)
        $_SESSION['full_name'] = $user['full_name']; // Store full name of the user

        // Log the login activity using the logAction function
        logAction($user['user_id'], 'login', "User {$user['username']} logged in.");

        // Redirect the user based on their user level
        if ($user['user_level'] === 1) { // Admin
            header("Location: admin_dashboard.php"); // Redirect to admin dashboard
        } elseif ($user['user_level'] === 2) { // Manager
            header("Location: manager_dashboard.php"); // Redirect to manager dashboard
        } elseif ($user['user_level'] === 3) { // Student
            header("Location: student_dashboard.php"); // Redirect to student dashboard
        } else {
            // In case of an unknown user level, show an error message
            $_SESSION['login_error'] = "Unknown user level.";
            header("Location: login.php");
        }
        exit;
    }
}

// If the credentials are invalid, show an error message
$_SESSION['login_error'] = "Invalid username or password.";
header("Location: index.php"); // Redirect back to the login page
exit;
