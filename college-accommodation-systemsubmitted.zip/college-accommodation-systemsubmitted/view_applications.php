<?php
require 'auth.php';  // Ensure the user is authenticated and logged in
checkLevel(2); // Only allow users with manager level (2) to access this page
require 'db_connect.php';  // Connect to the database

// Fetch all applications that are linked with users and colleges (joined with necessary tables)
$result = $conn->query("
    SELECT a.application_id, u.full_name, u.username, c.college_name,
           a.room_type, a.status, a.apply_date, a.semester
    FROM applications a
    JOIN users u ON a.student_id = u.user_id 
    JOIN colleges c ON a.college_id = c.college_id  
    ORDER BY a.status ASC, a.apply_date DESC  
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>View Applications</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/viewmanager.css">  <!-- Styles for this page -->
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar">
  <div class="navbar-logo"><h1>Student College Accommodation System</h1></div>
  <ul class="navbar-links">
    <!-- Navbar links for manager -->
    <li><a href="manager_dashboard.php">Dashboard</a></li>
    <li><a href="edit_profile.php">Profile</a></li>
    <li><a href="view_applications.php">Manage Applications</a></li>
    <li><a href="accommodation_record.php">Accommodation Record</a></li>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<!-- Main Content Area -->
<div class="content-container">
  <h2 class="page-title">All Student Applications</h2>

  <!-- Display any session feedback message (e.g. for success/failure actions) -->
  <?php if (isset($_SESSION['app_msg'])): ?>
    <div class="info-alert"><?= $_SESSION['app_msg']; unset($_SESSION['app_msg']); ?></div>
  <?php endif; ?>

  <!-- Table for displaying applications -->
  <div class="table-wrapper">
    <table class="app-table">
      <thead>
        <tr>
          <th>Student</th>  <!-- Student full name -->
          <th>Username</th>  <!-- Student username -->
          <th>College</th>  <!-- College name -->
          <th>Applied On</th>  <!-- Date when application was submitted -->
          <th>Room Type</th>  <!-- Type of room requested -->
          <th>Semester</th>  <!-- Semester the application is for -->
          <th>Status</th>  <!-- Current application status -->
          <th>Action</th>  <!-- Actions to approve or reject the application -->
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($row['full_name']) ?></td>  <!-- Display student full name -->
          <td><?= htmlspecialchars($row['username']) ?></td>  <!-- Display student username -->
          <td><?= htmlspecialchars($row['college_name']) ?></td>  <!-- Display college name -->
          <td><?= htmlspecialchars($row['apply_date']) ?></td>  <!-- Display application date -->
          <td><?= htmlspecialchars($row['room_type']) ?></td>  <!-- Display requested room type -->
          <td><?= htmlspecialchars($row['semester']) ?></td>  <!-- Display semester -->
          <td><span class="status-<?= $row['status'] ?>"><?= ucfirst(htmlspecialchars($row['status'])) ?></span></td>  <!-- Display status (pending, approved, or rejected) -->
          <td>
            <?php if ($row['status'] === 'pending'): ?>  <!-- Only show actions for pending applications -->
              <!-- Form to approve or reject the application -->
              <form method="post" action="process_application.php" class="inline-form">
                <input type="hidden" name="application_id" value="<?= $row['application_id'] ?>">
                <button type="submit" name="action" value="approve" class="btn-approve">Approve</button>  <!-- Approve button -->
                <button type="submit" name="action" value="reject" class="btn-reject">Reject</button>  <!-- Reject button -->
              </form>
            <?php else: ?>
              <span class="dash">–</span>  <!-- No actions if the application is already processed (not pending) -->
            <?php endif; ?>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>

  <!-- Back link to return to the manager dashboard -->
  <div class="back-link">
      <a href="manager_dashboard.php">← Back to Dashboard</a>
  </div>
</div>

</body>
</html>
