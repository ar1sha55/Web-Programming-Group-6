<?php
require 'auth.php'; // Include authentication to ensure the user is logged in
checkLevel(3); // Ensure only students (level 3) can access this page
require 'db_connect.php'; // Include database connection

// Fetch current semester from the semester_config table
$semRes = $conn->query("SELECT current_semester FROM semester_config LIMIT 1");
$current_semester = $semRes->fetch_assoc()['current_semester'] ?? "N/A"; // Get current semester, if not set, default to "N/A"

// Fetch colleges with available student slots
$collegeResult = $conn->query("
    SELECT college_id, college_name, available_slots 
    FROM colleges 
    WHERE available_slots > 0
");
$colleges = $collegeResult->fetch_all(MYSQLI_ASSOC); // Fetch all available colleges with slots

// Fetch available room types per college
$roomResult = $conn->query("
    SELECT college_id, room_type, available_beds 
    FROM rooms 
    WHERE available_beds > 0
");

$rooms = [];
// Organize room data by college ID
while ($row = $roomResult->fetch_assoc()) {
    $rooms[$row['college_id']][] = [
        'room_type' => $row['room_type'],
        'available_beds' => $row['available_beds']
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Apply for Accommodation</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css"> <!-- Link to the main CSS file -->
    <link rel="stylesheet" href="css/apply.css"> <!-- Link to the apply specific CSS file -->
    <script>
        // JavaScript function to update room types based on selected college
        const roomOptions = <?= json_encode($rooms) ?>; // Pass the room data from PHP to JavaScript

        // Function to update the room types dropdown when a college is selected
        function updateRoomTypes() {
            const collegeId = document.getElementById('college-select').value;
            const roomTypeSelect = document.getElementById('room-select');
            roomTypeSelect.innerHTML = '<option value="">-- Select Room Type --</option>'; // Reset room type options

            if (collegeId && roomOptions[collegeId]) {
                // If rooms are available for the selected college, populate room type options
                roomOptions[collegeId].forEach(room => {
                    const option = document.createElement('option');
                    option.value = room.room_type;
                    option.textContent = `${room.room_type} (${room.available_beds} beds available)`; // Show room type and available beds
                    roomTypeSelect.appendChild(option);
                });
                roomTypeSelect.disabled = false; // Enable room type selection
            } else {
                roomTypeSelect.disabled = true; // Disable room type selection if no rooms are available
            }
        }
    </script>
</head>
<body>

<!-- Navbar Section -->
<nav class="navbar">
    <div class="navbar-logo">
        <h1>Student College Accommodation System</h1>
    </div>
    <ul class="navbar-links">
        <li><a href="student_dashboard.php">Dashboard</a></li> <!-- Dashboard link for student -->
        <li><a href="edit_profile.php">Profile</a></li> <!-- Profile edit link for student -->
        <li><a href="apply_accommodation.php">Apply</a></li> <!-- Link to apply for accommodation -->
        <li><a href="view_my_application.php">My Applications</a></li> <!-- Link to view applications -->
        <li><a href="accommodation_record.php">Accommodation Record</a></li> <!-- Link to accommodation record -->
        <li><a href="logout.php">Logout</a></li> <!-- Logout link -->
    </ul>
</nav>

<!-- Application Section -->
<div class="apply-section">
    <div class="apply-container">
        <h2 class="apply-title">Apply for College Accommodation</h2>

        <!-- Display any application feedback messages -->
        <?php if (isset($_SESSION['application_feedback'])): ?>
            <div class="apply-alert">
                <?= $_SESSION['application_feedback'] ?>
            </div>
        <?php unset($_SESSION['application_feedback']); endif; ?>
        
        <!-- Display current semester information -->
        <p class="semester">Current Semester: <?= htmlspecialchars($current_semester) ?></p>

        <!-- Form for submitting accommodation application -->
        <form method="post" action="submit_application.php" class="apply-form">
            <label for="college-select">College:</label>
            <!-- Dropdown to select college -->
            <select name="college_id" id="college-select" onchange="updateRoomTypes()" required>
                <option value="">-- Select College --</option>
                <?php foreach ($colleges as $college): ?>
                    <option value="<?= htmlspecialchars($college['college_id']) ?>">
                        <?= htmlspecialchars($college['college_name']) ?> (<?= $college['available_slots'] ?> slots)
                    </option>
                <?php endforeach; ?>
            </select>

            <!-- Dropdown to select room type (updated dynamically based on selected college) -->
            <label for="room-select">Room Type:</label>
            <select name="room_type" id="room-select" disabled required>
                <option value="">-- Select Room Type --</option>
            </select>

            <!-- Submit button for the form -->
            <input type="submit" value="Submit Application" class="apply-button">
        </form>

        <!-- Link to go back to the student dashboard -->
        <div class="apply-back">
            <a href="student_dashboard.php">← Back to Dashboard</a>
        </div>
    </div>
</div>

</body>
</html>
