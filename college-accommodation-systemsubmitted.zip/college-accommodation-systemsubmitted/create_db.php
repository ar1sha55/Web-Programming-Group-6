<?php
require_once 'config.php';

// Connect to the MySQL database without selecting a specific database
$conn = new mysqli($db_host, $db_user, $db_pass);

// If there's a connection error, output the error message and terminate
if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}

// Create the database if it doesn't exist already
$conn->query("CREATE DATABASE IF NOT EXISTS $db_name");

// Select the database for further operations
$conn->select_db($db_name);

// Define the schema for the tables to be created in the database
$schema = <<<SQL
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,     -- Unique user ID
    username VARCHAR(50) UNIQUE NOT NULL,       -- Username, must be unique
    password VARCHAR(255) NOT NULL,             -- Password, should be hashed in real applications
    full_name VARCHAR(100) NOT NULL,            -- User's full name
    email VARCHAR(100),                         -- User's email address
    user_level INT NOT NULL COMMENT '1=admin, 2=manager, 3=student',  -- User role level
    phone_number VARCHAR(15),                   -- User's phone number
    address TEXT,                               -- User's address
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- Timestamp of when the user was created
);

CREATE TABLE IF NOT EXISTS students (
    student_id INT PRIMARY KEY,                 -- Student ID
    matric_number VARCHAR(20) UNIQUE NOT NULL,   -- Matriculation number (unique for each student)
    program VARCHAR(100),                       -- Program the student is enrolled in
    year INT,                                   -- Current year of study
    FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE -- Linking student with users table
);

CREATE TABLE IF NOT EXISTS managers (
    manager_id INT PRIMARY KEY,                 -- Manager ID
    department VARCHAR(100),                    -- Department that the manager belongs to
    office_phone VARCHAR(20),                   -- Manager's office phone number
    FOREIGN KEY (manager_id) REFERENCES users(user_id) ON DELETE CASCADE -- Linking manager with users table
);

CREATE TABLE IF NOT EXISTS colleges (
    college_id INT AUTO_INCREMENT PRIMARY KEY,  -- College ID
    college_name VARCHAR(100) NOT NULL,         -- Name of the college
    capacity INT NOT NULL,                      -- Total capacity of the college
    available_slots INT NOT NULL                -- Available slots for students in the college
);

CREATE TABLE IF NOT EXISTS rooms (
    room_id INT AUTO_INCREMENT PRIMARY KEY,    -- Room ID
    college_id INT NOT NULL,                    -- College ID (foreign key from colleges)
    room_type ENUM('single', 'double') NOT NULL, -- Room type (single or double)
    available_rooms INT NOT NULL,               -- Number of available rooms in that type
    available_beds INT NOT NULL,                -- Number of available beds in that room type
    FOREIGN KEY (college_id) REFERENCES colleges(college_id) ON DELETE CASCADE -- Linking room with college
);

CREATE TABLE IF NOT EXISTS applications (
    application_id INT AUTO_INCREMENT PRIMARY KEY, -- Application ID
    student_id INT NOT NULL,                       -- Student ID (foreign key)
    college_id INT NOT NULL,                       -- College ID (foreign key)
    room_type ENUM('single', 'double') NOT NULL,   -- Type of room requested
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',  -- Status of the application
    remarks TEXT,                                  -- Remarks or notes for the application
    apply_date DATE NOT NULL,                      -- Date the application was submitted
    semester VARCHAR(30) NOT NULL,                 -- Semester during which the application is made
    FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE,  -- Linking application with student
    FOREIGN KEY (college_id) REFERENCES colleges(college_id) ON DELETE CASCADE -- Linking application with college
);

CREATE TABLE IF NOT EXISTS accommodation_records (
    record_id INT AUTO_INCREMENT PRIMARY KEY,     -- Record ID
    student_id INT NOT NULL,                       -- Student ID (foreign key)
    college_id INT NOT NULL,                       -- College ID (foreign key)
    room_type ENUM('single', 'double') NOT NULL,   -- Room type
    approved_by INT NOT NULL,                      -- Manager who approved the accommodation
    approve_date DATE,                             -- Date when the accommodation was approved
    semester VARCHAR(30) NOT NULL,                 -- Semester of the accommodation record
    FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE,  -- Linking record with student
    FOREIGN KEY (college_id) REFERENCES colleges(college_id) ON DELETE CASCADE, -- Linking record with college
    FOREIGN KEY (approved_by) REFERENCES users(user_id) ON DELETE CASCADE -- Linking record with manager (approved by)
);

CREATE TABLE IF NOT EXISTS history_log (
    log_id INT AUTO_INCREMENT PRIMARY KEY,         -- Log ID
    user_id INT,                                   -- User ID (who performed the action)
    action_type ENUM('login', 'apply', 'approve', 'reject', 'edit_profile', 'add_user', 'delete_user'), -- Type of action
    description TEXT,                              -- Description of the action
    action_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Timestamp of when the action occurred
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE -- Linking log with user
);

CREATE TABLE IF NOT EXISTS semester_config (
    id INT AUTO_INCREMENT PRIMARY KEY,             -- Config ID
    current_semester VARCHAR(50) NOT NULL          -- Current active semester
);

SQL;

// Execute schema creation queries
$conn->multi_query($schema);

// Make sure all queries have been executed
while ($conn->more_results() && $conn->next_result()) {}

// Insert default users (admin, manager, and students)
$users = [
    ['Adam', 'admin1', 'admin1', 1, 'adam_admin@example.com', '0123456789', 'Admin Office'],
    ['Nurul', 'admin2', 'admin2', 1, 'nurul_admin@example.com', '0198765432', 'Admin HQ'],
    ['Haziq', 'manager1', 'manager1', 2, 'haziq_manager@example.com', '0132233445', 'Accommodation Office Block A'],
    ['Siti', 'manager2', 'manager2', 2, 'siti_manager@example.com', '0145566778', 'Accommodation Office Block B'],
    ['Hazirah', 'student1', 'student1', 3, 'hazirah_student@example.com', '0171122334', 'No. 5 Jalan Kolej, Skudai'],
    ['Akmal', 'student2', 'student2', 3, 'akmal_student@example.com', '0189988776', 'No. 8 Jalan Universiti, Skudai']
];

// Insert default users data into the `users` table
foreach ($users as $u) {
    $stmt = $conn->prepare("INSERT IGNORE INTO users (full_name, username, password, user_level, email, phone_number, address) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssisss", $u[0], $u[1], $u[2], $u[3], $u[4], $u[5], $u[6]);
    $stmt->execute();
    $userId = $conn->insert_id;
    if ($u[3] === 3) {
        $matric = "A20CS00$userId";
        // Assign program and year manually
        if ($u[0] === 'Hazirah') {
            $program = "Bachelor of Software Engineering";
            $year = 1;
        } elseif ($u[0] === 'Akmal') {
            $program = "Bachelor of Computer Science";
            $year = 3;
        }

        $stmt2 = $conn->prepare("INSERT IGNORE INTO students (student_id, matric_number, program, year) VALUES (?, ?, ?, ?)");
        $stmt2->bind_param("issi", $userId, $matric, $program, $year);
        $stmt2->execute();

    } elseif ($u[3] === 2) {

        if ($u[1] === 'manager1') {
            $dept = "Accommodation Unit A";
            $officePhone = "03-89211234";
        } elseif ($u[1] === 'manager2') {
            $dept = "Accommodation Unit B";
            $officePhone = "03-89214321";
        }

        $stmt3 = $conn->prepare("INSERT IGNORE INTO managers (manager_id, department, office_phone) VALUES (?, ?, ?)");
        $stmt3->bind_param("iss", $userId, $dept, $officePhone);
        $stmt3->execute();
    }
}

// Insert colleges (with initial slots set to 0)
$colleges = [
    ['Kolej Perdana (KP)', 100],  // College 1
    ['Kolej Tun Dr. Ismail (KTDI)', 100],  // College 2
    ['Kolej Tun Hussein Onn (KTHO)', 60],  // College 3
    ['Kolej Tuanku Rahman Putra (KTR)', 90],  // College 4
    ['Kolej Datin Seri Endon (KDSE)', 75],  // College 5
    ['Kolej Dato Onn Jaafar (KDOJ)', 110]  // College 6
];

// Insert college data into the `colleges` table
foreach ($colleges as $c) {
    $stmt = $conn->prepare("INSERT IGNORE INTO colleges (college_name, capacity, available_slots) VALUES (?, ?, 0)");
    $stmt->bind_param("si", $c[0], $c[1]);
    $stmt->execute();
}

// Insert rooms with room types and available beds
$rooms = [
    [1, 'Single', 50, 50], [1, 'Double', 25, 50],
    [2, 'Single', 1, 1], [2, 'Double', 1, 2],
    [3, 'Single', 30, 30], [3, 'Double', 15, 30],
    [4, 'Single', 40, 40], [4, 'Double', 25, 50],
    [5, 'Single', 25, 25], [5, 'Double', 25, 50],
    [6, 'Single', 50, 50], [6, 'Double', 30, 60]
];

// Insert room data into the `rooms` table
foreach ($rooms as $room) {
    $stmt = $conn->prepare("INSERT IGNORE INTO rooms (college_id, room_type, available_rooms, available_beds) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isii", $room[0], $room[1], $room[2], $room[3]);
    $stmt->execute();
}

// Sync available_slots based on available_beds in rooms table
$conn->query("
    UPDATE colleges c
    JOIN (
        SELECT college_id, SUM(available_beds) AS slots
        FROM rooms
        GROUP BY college_id
    ) r ON c.college_id = r.college_id
    SET c.available_slots = r.slots
");

// Insert default active semester
$conn->query("INSERT IGNORE INTO semester_config (id, current_semester) VALUES (1, '2024/2025 - Semester 1')");

echo "<h3>✅ Database, tables, users, colleges, and rooms created successfully!</h3>";
$conn->close();
?>

