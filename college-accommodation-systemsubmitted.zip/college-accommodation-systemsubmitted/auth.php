<?php
session_start(); // Start the session for the current user

// Check if the user is logged in by checking if 'user_id' is set in the session
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php"); // Redirect to login page if the user is not logged in
    exit; // Stop further execution of the script
}

// Function to check if the user has the required access level
function checkLevel($requiredLevel) {
    // Check if the 'user_level' is set and matches the required level
    if (!isset($_SESSION['user_level']) || $_SESSION['user_level'] !== $requiredLevel) {
        // Redirect to a page (e.g., index.php) if the user does not have the required level
        header("Location: index.php");
        exit; // Stop further execution of the script
    }
}
?>
