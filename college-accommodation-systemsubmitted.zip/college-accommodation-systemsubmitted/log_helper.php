<?php
// Include the database connection
require_once 'db_connect.php';

/**
 * Function to log actions performed by users
 * 
 * @param int $user_id - ID of the user performing the action
 * @param string $action_type - Type of the action (e.g., login, apply, approve)
 * @param string $description - A description of the action
 */
function logAction($user_id, $action_type, $description) {
    // Access the global database connection variable
    global $conn;

    // Sanitize the inputs
    $user_id = (int)$user_id; // Cast user_id to integer to prevent SQL injection
    $action_type = trim($action_type); // Remove any leading/trailing spaces from action type
    $description = trim($description); // Remove any leading/trailing spaces from the description

    // Prepare the SQL statement to insert the log into the database
    $stmt = $conn->prepare("INSERT INTO history_log (user_id, action_type, description) VALUES (?, ?, ?)");
    
    // Bind the parameters to the SQL statement (i = integer, s = string)
    $stmt->bind_param("iss", $user_id, $action_type, $description);

    // Execute the statement to insert the log entry into the database
    $stmt->execute();
}
