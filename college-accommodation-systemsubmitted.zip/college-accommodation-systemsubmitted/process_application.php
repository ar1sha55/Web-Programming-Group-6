<?php
require 'auth.php'; // Ensure the user is authenticated
checkLevel(2); // Manager level check (2 = manager)
require 'db_connect.php'; // Database connection
require_once 'log_helper.php'; // Logging helper to log actions

session_start(); // Start a session to track user activity

// Fetch application ID and action (approve/reject)
$application_id = intval($_POST['application_id']);
$action = $_POST['action'];
$manager_id = $_SESSION['user_id']; // Get the current manager's user ID from the session
$username = $_SESSION['username']; // Get the current manager's username from the session

// Get application information from the database
$stmt = $conn->prepare("
    SELECT a.student_id, a.college_id, a.room_type
    FROM applications a
    WHERE a.application_id = ? AND a.status = 'pending'
");
$stmt->bind_param("i", $application_id); // Bind the application ID parameter
$stmt->execute();
$app = $stmt->get_result()->fetch_assoc(); // Fetch the application details

// If no application or it's already processed, show an error and redirect
if (!$app) {
    $_SESSION['app_msg'] = "⚠️ Application not found or already processed."; // Set error message
    header("Location: view_applications.php"); // Redirect to the applications page
    exit;
}

$student_id = $app['student_id']; // Fetch student ID from the application
$college_id = $app['college_id']; // Fetch college ID from the application
$room_type = $app['room_type']; // Fetch room type from the application

// Fetch current semester
$sem_query = $conn->query("SELECT current_semester FROM semester_config LIMIT 1"); 
$semester = $sem_query && $sem_query->num_rows > 0 ? $sem_query->fetch_assoc()['current_semester'] : 'Unknown'; // Fetch the current semester

if ($action === 'approve') {
    // Check if there are available beds in the requested room type and college
    $check = $conn->prepare("SELECT available_beds FROM rooms WHERE college_id = ? AND room_type = ?");
    $check->bind_param("is", $college_id, $room_type);
    $check->execute();
    $room = $check->get_result()->fetch_assoc();

    // If no available beds, show an error and redirect
    if (!$room || $room['available_beds'] <= 0) {
        $_SESSION['app_msg'] = "❌ Cannot approve. No available $room_type rooms in this college."; // Set error message
        header("Location: view_applications.php"); // Redirect to the applications page
        exit;
    }

    // 1. Update application status to 'approved' and set the semester
    $stmt = $conn->prepare("UPDATE applications SET status = 'approved', remarks = 'Approved by manager', semester = ? WHERE application_id = ?");
    $stmt->bind_param("si", $semester, $application_id); // Bind parameters for semester and application ID
    $stmt->execute(); // Execute the update query

    // 2. Decrease available beds by 1
    $updateBeds = $conn->prepare("UPDATE rooms SET available_beds = available_beds - 1 WHERE college_id = ? AND room_type = ?");
    $updateBeds->bind_param("is", $college_id, $room_type); // Bind parameters for college ID and room type
    $updateBeds->execute(); // Execute the query to decrease available beds

    // 3. Sync college slots based on the available beds in rooms
    $conn->query("
        UPDATE colleges c
        JOIN (
            SELECT college_id, SUM(available_beds) AS slots
            FROM rooms
            GROUP BY college_id
        ) r ON c.college_id = r.college_id
        SET c.available_slots = r.slots
    ");

    // 4. Insert a record into the accommodation_records table to store approved accommodation
    $date = date('Y-m-d'); // Get today's date
    $stmt = $conn->prepare("
    INSERT INTO accommodation_records (student_id, college_id, room_type, approved_by, approve_date, semester)
    VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("iissss", $student_id, $college_id, $room_type, $manager_id, $date, $semester); // Bind parameters for the insert
    $stmt->execute(); // Execute the insert query

    // 5. Log the approval action
    logAction($manager_id, 'approve', "Manager $username approved application ID $application_id for semester $semester.");

    // Set success message and redirect
    $_SESSION['app_msg'] = "✅ Application approved.";
    header("Location: view_applications.php");
    exit;

} elseif ($action === 'reject') {
    // Reject the application and update its status
    $stmt = $conn->prepare("UPDATE applications SET status = 'rejected', remarks = 'Rejected by manager' WHERE application_id = ?");
    $stmt->bind_param("i", $application_id); // Bind the application ID parameter
    $stmt->execute(); // Execute the rejection query

    // Log the rejection action
    logAction($manager_id, 'reject', "Manager $username rejected application ID $application_id.");

    // Set rejection message and redirect
    $_SESSION['app_msg'] = "⚠️ Application rejected.";
    header("Location: view_applications.php");
    exit;

} else {
    // If the action is invalid, show an error message
    $_SESSION['app_msg'] = "❌ Invalid action.";
    header("Location: view_applications.php"); // Redirect to the applications page
    exit;
}

?>
