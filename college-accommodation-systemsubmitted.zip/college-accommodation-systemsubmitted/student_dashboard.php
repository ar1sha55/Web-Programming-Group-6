<?php
require 'auth.php'; // Ensures the user is logged in and authenticated
checkLevel(3); // 3 = student level, ensuring only students can access this page
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"> <!-- Set the character encoding to UTF-8 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Make the page responsive on different devices -->
    <title>Student Dashboard</title> <!-- Title of the page -->
    <link rel="stylesheet" href="css/style.css"> <!-- Link to the main stylesheet -->
    <link rel="stylesheet" href="css/dashboard.css"> <!-- Link to the specific dashboard stylesheet -->
</head>
<body>
<div class="dashboard-wrapper"> <!-- Container for the dashboard -->
    <!-- Navbar -->
    <nav class="navbar">
        <div class="navbar-logo">
            <h1>Student College Accommodation System</h1> <!-- Main logo or name of the system -->
        </div>
        <ul class="navbar-links">
            <!-- Links for navigation -->
            <li><a href="student_dashboard.php">Dashboard</a></li>
            <li><a href="edit_profile.php">Profile</a></li>
            <li><a href="apply_accommodation.php">Apply</a></li>
            <li><a href="view_my_application.php">My Applications</a></li>
            <li><a href="accommodation_record.php">Accommodation Record</a></li>
            <li><a href="logout.php">Logout</a></li> <!-- Logout link -->
        </ul>
    </nav>

    <!-- Dashboard Content -->
    <div class="dashboard-content">
       <h2 class="welcome-message">Welcome, <?= htmlspecialchars($_SESSION['full_name']) ?> (Student)</h2> <!-- Display the student's name -->

        <div class="dashboard-cards"> <!-- Card section to navigate through different functionalities -->
            <!-- Apply for accommodation -->
            <div class="card">
                <a href="apply_accommodation.php">
                    <span class="card-icon">📝</span> <!-- Icon for applying -->
                    <p>Apply for Accommodation</p> <!-- Description of the card -->
                </a>
            </div>
            <!-- View my application -->
            <div class="card">
                <a href="view_my_application.php">
                    <span class="card-icon">📄</span> <!-- Icon for viewing application -->
                    <p>View My Application</p> <!-- Description of the card -->
                </a>
            </div>
            <!-- Edit profile -->
            <div class="card">
                <a href="edit_profile.php">
                    <span class="card-icon">👤</span> <!-- Icon for profile -->
                    <p>Edit My Profile</p> <!-- Description of the card -->
                </a>
            </div>
            <!-- View accommodation record -->
            <div class="card">
                <a href="accommodation_record.php">
                    <span class="card-icon">🛏️</span> <!-- Icon for accommodation record -->
                    <p>View Accommodation Record</p> <!-- Description of the card -->
                </a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
