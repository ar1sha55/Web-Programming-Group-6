document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector("form");

  form.addEventListener("submit", function (e) {

    const usernameField = form.querySelector('input[name="username"]');
    const passwordField = form.querySelector('input[name="password"]');
    const role = form.querySelector('select[name="user_level"]');

        // Validate Username (should not be empty or just spaces)
        if (usernameField && usernameField.value.trim() === '') {
            alert("Username is required.");
            usernameField.focus();
            e.preventDefault(); // Stop form submission
            return;
        }

        // Validate Password (should not be empty or just spaces)
        if (passwordField && passwordField.value.trim() === '') {
            alert("Password is required.");
            passwordField.focus();
            e.preventDefault(); // Stop form submission
            return;
        }

    // Role-specific fields
    const selectedRole = role.value;

    if (selectedRole === "2") {
      const dept = form.querySelector('input[name="department"]');
      const officePhone = form.querySelector('input[name="office_phone"]');

      if (!dept.value.trim()) {
        alert("Department is required.");
        dept.focus();
        e.preventDefault();
        return;
      }

      if (!officePhone.value.trim()) {
        alert("Office phone is required.");
        officePhone.focus();
        e.preventDefault();
        return;
      }

      const officePhoneRegex = /^[0-9\-]{8,20}$/;
      if (!officePhoneRegex.test(officePhone.value)) {
        alert("Invalid office phone format (8–20 digits, numbers/dashes only).");
        officePhone.focus();
        e.preventDefault();
        return;
      }
    }

    if (selectedRole === "3") {
      const matric = form.querySelector('input[name="matric_number"]');
      const program = form.querySelector('input[name="program"]');
      const year = form.querySelector('input[name="year"]');

      if (!matric.value.trim()) {
        alert("Matric number is required.");
        matric.focus();
        e.preventDefault();
        return;
      }

      if (!program.value.trim()) {
        alert("Program is required.");
        program.focus();
        e.preventDefault();
        return;
      }

      const yearVal = parseInt(year.value);
      if (!year.value.trim() || isNaN(yearVal) || yearVal < 1 || yearVal > 4) {
        alert("Year must be between 1 and 4.");
        year.focus();
        e.preventDefault();
        return;
      }
    }
  });
});
