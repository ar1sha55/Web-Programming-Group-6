function searchTable() {
    let input = document.getElementById("search").value.toLowerCase();
    let table = document.querySelector(".record-table");
    let rows = table.getElementsByTagName("tr");

    for (let i = 1; i < rows.length; i++) {
        let cells = rows[i].getElementsByTagName("td");

        // Get data from each column
        let studentName = cells[0] ? cells[0].innerText.toLowerCase() : "";  // Student Name in cells[0]
        let collegeName = cells[1] ? cells[1].innerText.toLowerCase() : "";   // College Name in cells[1]
        let roomType = cells[3] ? cells[3].innerText.toLowerCase() : "";     // Room Type in cells[3]
        let semester = cells[2] ? cells[2].innerText.toLowerCase() : "";      // Semester in cells[2]

        // Check if any of the columns contain the search term
        if (studentName.indexOf(input) > -1 || 
            collegeName.indexOf(input) > -1 || 
            roomType.indexOf(input) > -1 || 
            semester.indexOf(input) > -1) {
            rows[i].style.display = "";
        } else {
            rows[i].style.display = "none";
        }
    }
}