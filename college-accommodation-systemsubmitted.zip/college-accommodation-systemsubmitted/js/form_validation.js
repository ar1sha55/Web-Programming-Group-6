document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("form");

    form.addEventListener("submit", function (e) {
        // General validation for all forms
        const fullNameField = form.querySelector('input[name="full_name"]');
        if (fullNameField && fullNameField.value.trim() === '') {
            alert("Full name is required.");
            fullNameField.focus();
            e.preventDefault(); // Stop form submission
            return;
        }

        const emailField = form.querySelector('input[name="email"]');
        if (emailField && emailField.value.trim() === '') {
            alert("Email is required.");
            emailField.focus();
            e.preventDefault();
            return;
        }
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (emailField && !emailRegex.test(emailField.value)) {
            alert("Please enter a valid email address.");
            emailField.focus();
            e.preventDefault();
            return;
        }

        const phoneField = form.querySelector('input[name="phone_number"]');
        if (phoneField && phoneField.value.trim() === '') {
            alert("Phone number is required.");
            phoneField.focus();
            e.preventDefault();
            return;
        }
        const phoneRegex = /^[0-9]{10,15}$/;
        if (phoneField && !phoneRegex.test(phoneField.value)) {
            alert("Phone number must be 10–15 digits.");
            phoneField.focus();
            e.preventDefault();
            return;
        }

        const addressField = form.querySelector('textarea[name="address"]');
        if (addressField && addressField.value.trim() === '') {
            alert("Address is required.");
            addressField.focus();
            e.preventDefault();
            return;
        }

        
    });
});
