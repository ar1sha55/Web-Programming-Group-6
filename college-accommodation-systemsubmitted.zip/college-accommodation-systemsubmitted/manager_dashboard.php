<?php
// Check if the logged-in user is a manager (level 2)
require 'auth.php'; 
checkLevel(2); // 2 = manager
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manager Dashboard</title> <!-- Title for the Manager Dashboard page -->
    <link rel="stylesheet" href="css/style.css"> <!-- Main stylesheet for styling -->
    <link rel="stylesheet" href="css/dashboard.css"> <!-- Custom stylesheet for the dashboard -->
</head>
<body>

<div class="dashboard-wrapper">
    <!-- Navbar Section -->
    <nav class="navbar">
        <div class="navbar-logo">
            <h1>Student College Accommodation System</h1> <!-- Logo for the system -->
        </div>
        <ul class="navbar-links">
            <!-- Navbar links specific to Manager role -->
            <li><a href="manager_dashboard.php">Dashboard</a></li> <!-- Link to Dashboard -->
            <li><a href="edit_profile.php">Profile</a></li> <!-- Link to Edit Profile page -->
            <li><a href="view_applications.php">Manage Applications</a></li> <!-- Link to Manage Applications page -->
            <li><a href="accommodation_record.php">Accommodation Record</a></li> <!-- Link to View Accommodation Records -->
            <li><a href="logout.php">Logout</a></li> <!-- Link to Logout -->
        </ul>
    </nav>

    <div class="dashboard-content">
        <!-- Welcome message displaying the manager's full name -->
        <h2 class="welcome-message">Welcome, <?= htmlspecialchars($_SESSION['full_name']) ?> (Manager)</h2>

        <!-- Dashboard cards section -->
        <div class="dashboard-cards">
            <!-- Card for viewing and managing applications -->
            <div class="card">
                <a href="view_applications.php">
                    <span class="card-icon">📝</span> <!-- Icon for the card -->
                    <p>View and Manage Applications</p> <!-- Description for the card -->
                </a>
            </div>
            
            <!-- Card for editing the manager's profile -->
            <div class="card">
                <a href="edit_profile.php">
                    <span class="card-icon">👤</span> <!-- Icon for the card -->
                    <p>Edit My Profile</p> <!-- Description for the card -->
                </a>
            </div>
            
            <!-- Card for viewing accommodation records -->
            <div class="card">
                <a href="accommodation_record.php">
                    <span class="card-icon">🛏️</span> <!-- Icon for the card -->
                    <p>View Accommodation Record</p> <!-- Description for the card -->
                </a>
            </div>
        </div>
    </div>
</div>

</body>
</html>
