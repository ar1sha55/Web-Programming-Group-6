<?php
require 'auth.php'; // Ensures user is logged in
checkLevel(3); // 3 = student, ensures the current user is a student
require 'db_connect.php'; // Establish a connection to the database

$student_id = $_SESSION['user_id']; // Get the student ID from the session
$college_id = intval($_POST['college_id']); // Get the college ID from the form submission
$room_type = $_POST['room_type']; // Get the room type from the form submission
$apply_date = date('Y-m-d'); // Get today's date for application date

// Get current semester from the semester_config table
$semRes = $conn->query("SELECT current_semester FROM semester_config LIMIT 1");
$current_semester = $semRes->fetch_assoc()['current_semester'] ?? null; // Fetch current semester, default to null if not found

// If the current semester is not set, show an error and exit
if (!$current_semester) {
    $_SESSION['application_feedback'] = "❌ Semester configuration missing. Please contact administrator.";
    header("Location: apply_accommodation.php");
    exit;
}

// Check if the student already has a pending application for the current semester
$check_pending = $conn->prepare("SELECT 1 FROM applications WHERE student_id = ? AND semester = ? AND status = 'pending'");
$check_pending->bind_param("is", $student_id, $current_semester); // Bind parameters to avoid SQL injection
$check_pending->execute();
if ($check_pending->get_result()->num_rows > 0) {
    $_SESSION['application_feedback'] = "⚠️ You already have a pending application for $current_semester.";
    header("Location: apply_accommodation.php");
    exit;
}

// Check if the student already has an approved application for the current semester
$check_approved = $conn->prepare("SELECT 1 FROM applications WHERE student_id = ? AND semester = ? AND status = 'approved'");
$check_approved->bind_param("is", $student_id, $current_semester);
$check_approved->execute();
if ($check_approved->get_result()->num_rows > 0) {
    $_SESSION['application_feedback'] = "❌ You already have an approved application for $current_semester.";
    header("Location: apply_accommodation.php");
    exit;
}

// Check availability of selected room type in the selected college
$check_availability = $conn->prepare("SELECT available_beds FROM rooms WHERE college_id = ? AND room_type = ?");
$check_availability->bind_param("is", $college_id, $room_type);
$check_availability->execute();
$bedResult = $check_availability->get_result()->fetch_assoc(); // Fetch the result of available beds

// If no available beds or the available beds are zero, show an error and exit
if (!$bedResult || $bedResult['available_beds'] <= 0) {
    $_SESSION['application_feedback'] = "❌ No available beds for selected room type at this college.";
    header("Location: apply_accommodation.php");
    exit;
}

// If all checks pass, insert the application into the database
$stmt = $conn->prepare("INSERT INTO applications (student_id, college_id, room_type, apply_date, semester) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("iisss", $student_id, $college_id, $room_type, $apply_date, $current_semester); // Bind parameters for insertion

if ($stmt->execute()) {
    // Sync the available slots in the colleges table
    $conn->query("
        UPDATE colleges c
        JOIN (
            SELECT college_id, SUM(available_beds) AS slots
            FROM rooms
            GROUP BY college_id
        ) r ON c.college_id = r.college_id
        SET c.available_slots = r.slots
    ");

    // Log the action (using the helper function)
    require_once 'log_helper.php';
    logAction($student_id, 'apply', "Applied for $current_semester: college $college_id, room $room_type.");

    // Set feedback for successful application submission
    $_SESSION['application_feedback'] = "✅ Application for $current_semester submitted successfully.";
    header("Location: apply_accommodation.php"); // Redirect to application page
    exit;
} else {
    // If insertion fails, set feedback with the error message
    $_SESSION['application_feedback'] = "❌ Failed to submit application: " . $stmt->error;
    header("Location: apply_accommodation.php"); // Redirect to application page
    exit;
}
?>
