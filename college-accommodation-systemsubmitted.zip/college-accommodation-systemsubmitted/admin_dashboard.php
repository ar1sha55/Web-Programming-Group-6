<?php
require 'auth.php'; // Includes authentication checks (ensures the user is logged in)
checkLevel(1); // Ensure only Admin (level 1) can access this page
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <!-- Link to external CSS for styling the page -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/dashboard.css">
</head>
<body>

<div class="dashboard-wrapper">
    <!-- Navbar Section -->
    <nav class="navbar">
        <div class="navbar-logo">
            <h1>Student College Accommodation System</h1> <!-- Display the logo and title -->
        </div>
        <ul class="navbar-links">
            <!-- Navigation Links for Admin Dashboard -->
            <li><a href="manager_dashboard.php">Dashboard</a></li>
            <li><a href="manage_users.php">Manage Users</a></li>
            <li><a href="view_logs.php">System Logs</a></li>
            <li><a href="manage_semester.php">Manage Semester</a></li>
            <li><a href="logout.php">Logout</a></li> <!-- Logout link -->
        </ul>
    </nav>

    <!-- Main Dashboard Content Section -->
    <div class="dashboard-content">
        <h2 class="welcome-message">Welcome, <?= htmlspecialchars($_SESSION['full_name']) ?> (Admin)</h2> <!-- Display admin's name -->

        <!-- Cards displaying key sections of the admin panel -->
        <div class="dashboard-cards">
            <!-- Card for managing users -->
            <div class="card">
                <a href="manage_users.php">
                    <span class="card-icon">📝</span>
                    <p>Manage Users</p>
                </a>
            </div>
            <!-- Card for viewing system logs -->
            <div class="card">
                <a href="view_logs.php">
                    <span class="card-icon">📄</span>
                    <p>View System Logs</p>
                </a>
            </div>
            <!-- Card for managing semesters -->
            <div class="card">
                <a href="manage_semester.php">
                    <span class="card-icon">🗓️</span>
                    <p>Manage Semester</p>
                </a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
