<?php
require 'auth.php'; // Ensures the user is authenticated and logged in
checkLevel(1); // Only allow admins to access this page

require 'db_connect.php'; // Connect to the database
require_once 'log_helper.php'; // Include log helper to log actions

// Retrieve data from the form (POST request)
$user_id = intval($_POST['user_id']); // User ID (ensure it is an integer)
$full_name = trim($_POST['full_name']); // Full name, trimmed for whitespace
$username = trim($_POST['username']); // Username, trimmed for whitespace
$password = trim($_POST['password']); // Password (plain-text, should ideally be hashed)
$email = trim($_POST['email']); // Email, trimmed for whitespace
$user_level = intval($_POST['user_level']); // User level (admin=1, manager=2, student=3)

// Basic validation to ensure all necessary fields are filled and valid
if (!$user_id || !$full_name || !$username || !$password || !in_array($user_level, [1, 2, 3])) {
    die("⚠️ Missing or invalid input."); // Stop execution and display error if validation fails
}

// Prepare and execute the query to update the main user info in the database
$stmt = $conn->prepare("UPDATE users SET full_name = ?, username = ?, password = ?, email = ?, user_level = ? WHERE user_id = ?");
$stmt->bind_param("ssssii", $full_name, $username, $password, $email, $user_level, $user_id); // Bind parameters to prevent SQL injection
if (!$stmt->execute()) {
    die("❌ Failed to update user: " . $stmt->error); // Display error if the query fails
}

// Role-specific info update (for students and managers)
if ($user_level === 3) { // If the user is a student
    // Retrieve additional student-specific fields
    $program = trim($_POST['program']); // Program of study (trimmed)
    $year = intval($_POST['year']); // Year of study (integer)

    // Prepare and execute the query to update the student's information
    $stmt = $conn->prepare("UPDATE students SET program = ?, year = ? WHERE student_id = ?");
    $stmt->bind_param("sii", $program, $year, $user_id); // Bind parameters to prevent SQL injection
    $stmt->execute(); // Execute the query
} elseif ($user_level === 2) { // If the user is a manager
    // Retrieve additional manager-specific fields
    $department = trim($_POST['department']); // Department name (trimmed)
    $office_phone = trim($_POST['office_phone']); // Manager's office phone number (trimmed)

    // Prepare and execute the query to update the manager's information
    $stmt = $conn->prepare("UPDATE managers SET department = ?, office_phone = ? WHERE manager_id = ?");
    $stmt->bind_param("ssi", $department, $office_phone, $user_id); // Bind parameters to prevent SQL injection
    $stmt->execute(); // Execute the query
}

// Log the activity (track what admin does)
logAction($_SESSION['user_id'], 'edit_profile', "Admin {$_SESSION['username']} updated user $username (ID: $user_id)");

// Redirect to the manage users page after the update is complete
header("Location: manage_users.php");
exit;
