<?php
require 'auth.php'; // Ensure the user is logged in
checkLevel(1); // Check if the user has the correct level (Admin)

require 'db_connect.php'; // Include the database connection

// Get the current user ID and user level from the session
$user_id = $_SESSION['user_id'];
$user_level = $_SESSION['user_level'];

// Fetch basic user details (full name, email, phone number, address)
$stmt = $conn->prepare("SELECT full_name, email, phone_number, address FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id); // Bind the user ID parameter
$stmt->execute(); // Execute the query
$userResult = $stmt->get_result(); // Get the result of the query
if ($userResult->num_rows === 0) {
    die("❌ User not found."); // If no user is found, show an error
}
$user = $userResult->fetch_assoc(); // Fetch the user's details into an associative array

$extra = []; // Array to hold additional information depending on the user level
if ($user_level === 3) {
    // If the user is a student, fetch student-specific details
    $stmt = $conn->prepare("SELECT matric_number, program, year FROM students WHERE student_id = ?");
    $stmt->bind_param("i", $user_id); // Bind the user ID parameter
    $stmt->execute(); // Execute the query
    $extra = $stmt->get_result()->fetch_assoc(); // Fetch the student's specific details
} elseif ($user_level === 2) {
    // If the user is a manager, fetch manager-specific details
    $stmt = $conn->prepare("SELECT department, office_phone FROM managers WHERE manager_id = ?");
    $stmt->bind_param("i", $user_id); // Bind the user ID parameter
    $stmt->execute(); // Execute the query
    $extra = $stmt->get_result()->fetch_assoc(); // Fetch the manager's specific details
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Profile</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/style.css"> <!-- Link to main styles -->
  <link rel="stylesheet" href="css/editprofile.css"> <!-- Link to profile editing styles -->
</head>
<body>

  <!-- Navbar for navigation -->
  <nav class="navbar">
    <div class="navbar-logo"><h1>Student College Accommodation System</h1></div>
    <ul class="navbar-links">
        <?php if ($user_level === 3): // If the user is a student ?>
            <li><a href="student_dashboard.php">Dashboard</a></li>
            <li><a href="edit_profile.php">Profile</a></li>
            <li><a href="apply_accommodation.php">Apply</a></li>
            <li><a href="view_my_application.php">My Applications</a></li>
            <li><a href="accommodation_record.php">Accommodation Record</a></li>
        <?php elseif ($user_level === 2): // If the user is a manager ?>
            <li><a href="manager_dashboard.php">Dashboard</a></li>
            <li><a href="edit_profile.php">Profile</a></li>
            <li><a href="view_applications.php">Manage Applications</a></li>
            <li><a href="accommodation_record.php">Accommodation Record</a></li>
        <?php endif; ?>
            <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>

  <!-- Profile edit section -->
  <div class="edit-container">
    <h2 class="edit-title">Edit My Profile</h2>

    <!-- Show success message after profile update -->
    <?php if (isset($_SESSION['profile_update_success'])): ?>
      <div class="edit-success"><?= $_SESSION['profile_update_success'] ?></div>
      <?php unset($_SESSION['profile_update_success']); ?>
    <?php endif; ?>

    <!-- Profile edit form -->
    <form class="edit-form" method="post" action="update_profile.php">
      <fieldset>
        <legend>🔒 Account Info</legend>
        <label>Full Name:</label>
        <input type="text" name="full_name" value="<?= htmlspecialchars($user['full_name']) ?>" > <!-- Pre-fill with current name -->

        <label>Email:</label>
        <input type="text" name="email" value="<?= htmlspecialchars($user['email']) ?>"> <!-- Pre-fill with current email -->

        <label>Phone:</label>
        <input type="text" name="phone_number" value="<?= htmlspecialchars($user['phone_number']) ?>"> <!-- Pre-fill with current phone number -->

        <label>Address:</label>
        <textarea name="address"><?= htmlspecialchars($user['address']) ?></textarea> <!-- Pre-fill with current address -->
      </fieldset>

      <?php if ($user_level === 3): // If the user is a student, show student information ?>
        <fieldset>
          <legend>🎓 Student Info</legend>
          <p><strong>Matric Number:</strong> <?= htmlspecialchars($extra['matric_number']) ?></p>
          <p><strong>Program:</strong> <?= htmlspecialchars($extra['program']) ?></p>
          <p><strong>Year:</strong> <?= htmlspecialchars($extra['year']) ?></p>
        </fieldset>
      <?php elseif ($user_level === 2): // If the user is a manager, show manager information ?>
        <fieldset>
          <legend>🏢 Manager Info</legend>
          <p><strong>Department:</strong> <?= htmlspecialchars($extra['department']) ?></p>
          <p><strong>Office Phone:</strong> <?= htmlspecialchars($extra['office_phone']) ?></p>
        </fieldset>
      <?php endif; ?>

      <input class="edit-submit" type="submit" value="Update My Profile"> <!-- Submit button -->
    </form>

    <!-- Back to dashboard link -->
    <div class="edit-back">
        <a href="<?= $user_level === 2 ? 'manager_dashboard.php' : 'student_dashboard.php' ?>">← Back to Dashboard</a>
    </div>
  </div>

  <!-- Validation scripts -->
  <script src="js/form_validation.js" defer></script>
</body>
</html>
