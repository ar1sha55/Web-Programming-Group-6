document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector("form");

  form.addEventListener("submit", function (e) {
    
     // Validation for edit user
        const usernameField = form.querySelector('input[name="username"]');
        const passwordField = form.querySelector('input[name="password"]');

        // Validate Username (should not be empty or just spaces)
        if (usernameField && usernameField.value.trim() === '') {
            alert("Username is required.");
            usernameField.focus();
            e.preventDefault(); // Stop form submission
            return;
        }

        // Validate Password (should not be empty or just spaces)
        if (passwordField && passwordField.value.trim() === '') {
            alert("Password is required.");
            passwordField.focus();
            e.preventDefault(); // Stop form submission
            return;
        }

         // Matric Number (student)
        const matricField = form.querySelector('input[name="matric_number"]');
        if (matricField && matricField.value.trim() === '') {
            alert("Matric number .");
            matricField.focus();
            e.preventDefault();
            return;
        }

        // Program (student)
        const programField = form.querySelector('input[name="program"]');
        if (programField && programField.value.trim() === '') {
            alert("Program is required.");
            programField.focus();
            e.preventDefault();
            return;
        }

        // Year (student: must be 1–4)
        const yearField = form.querySelector('input[name="year"]');
        if (yearField) {
            const year = parseInt(yearField.value.trim(), 10);
            if (isNaN(year) || year < 1 || year > 4) {
                alert("Year must be between 1 and 4.");
                yearField.focus();
                e.preventDefault();
                return;
            }
        }

        // Department (manager)
        const deptField = form.querySelector('input[name="department"]');
        if (deptField && deptField.value.trim() === '') {
            alert("Department is required.");
            deptField.focus();
            e.preventDefault();
            return;
        }

        // Office Phone (manager)
        const officePhoneField = form.querySelector('input[name="office_phone"]');
        if (officePhoneField && officePhoneField.value.trim() === '') {
            alert("Office phone is required.");
            officePhoneField.focus();
            e.preventDefault();
            return;
        }
        const officePhoneRegex = /^[0-9\-]{8,20}$/;
        if (officePhoneField && !officePhoneRegex.test(officePhoneField.value)) {
            alert("Please enter a valid office phone (numbers and dashes only).");
            officePhoneField.focus();
            e.preventDefault();
            return;
        }

  });
});
