<?php 
session_start(); 

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['user_level'] === 1) {
        header("Location: admin_dashboard.php");
        exit;
    } elseif ($_SESSION['user_level'] === 2) {
        header("Location: manager_dashboard.php");
        exit;
    } elseif ($_SESSION['user_level'] === 3) {
        header("Location: student_dashboard.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <title>Login | Student Accommodation</title>
   <link rel="stylesheet" href="css/style.css" />
   <link rel="stylesheet" href="css/index.css" />
</head>
<body>
   <div class="login-wrapper">
     <!-- System Title -->
     <div class="system-name">
       <h1>Student College Accommodation System</h1>
     </div>

     <!-- Login Form Card -->
     <div class="login-container">
       <h2>👤 User Login</h2>

       <?php if (isset($_SESSION['login_error'])): ?>
         <div class="alert error">
           <?= $_SESSION['login_error']; ?>
         </div>
         <?php unset($_SESSION['login_error']); ?>
       <?php endif; ?>

       <form method="post" action="login_process.php">
         <label for="username">Username</label>
         <input type="text" id="username" name="username" placeholder="Your username"/>

         <label for="password">Password</label>
         <input type="password" id="password" name="password" placeholder="Your password"/>

         <input type="submit" value="Login" class="login-button" />
       </form>
     </div>
   </div>

<!-- For Validation Purpose -->
<script src="js/form_validation.js" defer></script>

</body>
</html>
