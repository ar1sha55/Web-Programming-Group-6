<?php
require 'auth.php';
require 'db_connect.php';

$user_id = $_SESSION['user_id'];
$user_level = $_SESSION['user_level'];

$order = isset($_GET['sort']) && $_GET['sort'] === 'desc' ? 'DESC' : 'ASC';

if ($user_level === 2) {
    // Manager view: fetch all records
    $stmt = $conn->prepare("
        SELECT ar.*, ar.room_type, u.full_name AS student_name, c.college_name, m.full_name AS manager_name
        FROM accommodation_records ar
        JOIN users u ON ar.student_id = u.user_id
        JOIN colleges c ON ar.college_id = c.college_id
        JOIN users m ON ar.approved_by = m.user_id
        ORDER BY student_name $order
    ");
    $stmt->execute();
    $result = $stmt->get_result();
} elseif ($user_level === 3) {
    // Student view: fetch only own records
    $stmt = $conn->prepare("
        SELECT ar.*, ar.room_type, c.college_name, u.full_name AS manager_name
        FROM accommodation_records ar
        JOIN colleges c ON ar.college_id = c.college_id
        JOIN users u ON ar.approved_by = u.user_id
        WHERE ar.student_id = ?
        ORDER BY ar.approve_date DESC
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Accommodation Records</title>
  <link rel="stylesheet" href="css/style.css" />
  <link rel="stylesheet" href="css/accommodation_record.css" />
</head>
<body>

<nav class="navbar">
  <div class="navbar-logo">
    <h1>Student College Accommodation System</h1>
  </div>
  <ul class="navbar-links">
    <?php if ($user_level === 2): ?>
      <li><a href="manager_dashboard.php">Dashboard</a></li>
      <li><a href="edit_profile.php">Profile</a></li>
      <li><a href="view_applications.php">Manage Applications</a></li>
      <li><a href="accommodation_record.php">Accommodation Record</a></li>
    <?php elseif ($user_level === 3): ?>
      <li><a href="student_dashboard.php">Dashboard</a></li>
      <li><a href="edit_profile.php">Profile</a></li>
      <li><a href="apply_accommodation.php">Apply</a></li>
      <li><a href="view_my_application.php">My Applications</a></li>
      <li><a href="accommodation_record.php">Accommodation Record</a></li>
    <?php endif; ?>
    <li><a href="logout.php">Logout</a></li>
  </ul>
</nav>

<div class="record-container">
  <h2 class="record-title">
    <?= $user_level === 2 ? 'All Accommodation Records' : 'My Accommodation Records' ?>
  </h2>

  <?php if ($user_level === 2): ?>
    <div class="sort-links">
      Sort by Student:
      <a href="?sort=asc">A–Z</a> |
      <a href="?sort=desc">Z–A</a>
    </div>
  <?php endif; ?>

  <?php if ($result->num_rows > 0): ?>
    <div class="record-table-wrapper">
      <table class="record-table">
        <thead>
          <tr>
            <?php if ($user_level === 2): ?><th>Student Name</th><?php endif; ?>
            <th>Semester</th>
            <th>College</th>
            <th>Room Type</th>
            <th>Approved By</th>
            <th>Approval Date</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <?php if ($user_level === 2): ?><td><?= htmlspecialchars($row['student_name']) ?></td><?php endif; ?>
            <td><?= htmlspecialchars($row['semester']) ?></td>
            <td><?= htmlspecialchars($row['college_name']) ?></td>
            <td><?= ucfirst(htmlspecialchars($row['room_type'])) ?></td>
            <td><?= htmlspecialchars($row['manager_name']) ?></td>
            <td><?= htmlspecialchars($row['approve_date']) ?></td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <p class="no-record">⚠️ No accommodation records found.</p>
  <?php endif; ?>

  <div class="record-back">
    <a href="<?= $user_level === 2 ? 'manager_dashboard.php' : 'student_dashboard.php' ?>">← Back to Dashboard</a>
  </div>
</div>

</body>
</html>
