<?php
require 'auth.php';
checkLevel(1);
require 'db_connect.php';

$semester_options = [
    '2024/2025 Semester 1',
    '2024/2025 Semester 2',
    '2025/2026 Semester 1',
    '2025/2026 Semester 2',
    '2026/2027 Semester 1',
    '2026/2027 Semester 2'
];

// Fetch current semester
$current = 'Not Set';
$result = $conn->query("SELECT current_semester FROM semester_config LIMIT 1");
if ($row = $result->fetch_assoc()) {
    $current = $row['current_semester'];
}

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_semester'])) {
    $new_semester = trim($_POST['new_semester']);
    if (!in_array($new_semester, $semester_options)) {
        $_SESSION['sem_msg'] = "❌ Invalid semester selected.";
    } elseif ($new_semester === $current) {
        $_SESSION['sem_msg'] = "⚠️ No changes made. Selected semester is already active.";
    } else {
        $stmt = $conn->prepare("UPDATE semester_config SET current_semester = ? LIMIT 1");
        $stmt->bind_param("s", $new_semester);
        $stmt->execute();
        $_SESSION['sem_msg'] = "✅ Semester updated to: $new_semester";
    }
    header("Location: manage_semester.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1.0" />
  <title>Semester Configuration</title>
  <link rel="stylesheet" href="css/style.css" />
  <link rel="stylesheet" href="css/manage_semester.css" />
</head>
<body>

  <!-- Navbar -->
  <nav class="navbar">
    <div class="navbar-logo">
      <h1>Student College Accommodation System</h1>
    </div>
    <ul class="navbar-links">
      <li><a href="manager_dashboard.php">Dashboard</a></li>
      <li><a href="manage_users.php">Manage Users</a></li>
      <li><a href="view_logs.php">System Logs</a></li>
      <li><a href="manage_semester.php">Manage Semester</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>

  <div class="semester-container">
    <h2 class="semester-title">Manage Semester</h2>

    <?php if (isset($_SESSION['sem_msg'])): ?>
      <div class="semester-alert"><?= $_SESSION['sem_msg']; unset($_SESSION['sem_msg']); ?></div>
    <?php endif; ?>

    <div class="semester-current">
      <strong>Current Semester:</strong> <span class="semester-value"><?= htmlspecialchars($current) ?></span>
    </div>

    <form method="POST" class="semester-form">
      <label for="new_semester">Select Semester:</label>
      <select name="new_semester" id="new_semester" required>
        <option value="">-- Select Semester --</option>
        <?php foreach ($semester_options as $sem): ?>
          <option value="<?= $sem ?>" <?= $sem === $current ? 'selected' : '' ?>><?= $sem ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="semester-button">Update Semester</button>
    </form>

    <div class="semester-back">
      <a href="admin_dashboard.php">← Back to Dashboard</a>
    </div>
  </div>

</body>
</html>
