<?php
require 'auth.php';
checkLevel(3); // 3 = student
require 'db_connect.php';

$student_id = $_SESSION['user_id'];
$college_id = intval($_POST['college_id']);
$room_type = $_POST['room_type'];
$apply_date = date('Y-m-d');

// Get current semester from config
$semRes = $conn->query("SELECT current_semester FROM semester_config LIMIT 1");
$current_semester = $semRes->fetch_assoc()['current_semester'] ?? null;

if (!$current_semester) {
    $_SESSION['application_feedback'] = "❌ Semester configuration missing. Please contact administrator.";
    header("Location: apply_accommodation.php");
    exit;
}

// Check if student has a pending application in the same semester
$check_pending = $conn->prepare("SELECT 1 FROM applications WHERE student_id = ? AND semester = ? AND status = 'pending'");
$check_pending->bind_param("is", $student_id, $current_semester);
$check_pending->execute();
if ($check_pending->get_result()->num_rows > 0) {
    $_SESSION['application_feedback'] = "⚠️ You already have a pending application for $current_semester.";
    header("Location: apply_accommodation.php");
    exit;
}

// Check if already approved in the same semester
$check_approved = $conn->prepare("SELECT 1 FROM applications WHERE student_id = ? AND semester = ? AND status = 'approved'");
$check_approved->bind_param("is", $student_id, $current_semester);
$check_approved->execute();
if ($check_approved->get_result()->num_rows > 0) {
    $_SESSION['application_feedback'] = "❌ You already have an approved application for $current_semester.";
    header("Location: apply_accommodation.php");
    exit;
}

// Check availability of selected room type in the selected college
$check_availability = $conn->prepare("SELECT available_beds FROM rooms WHERE college_id = ? AND room_type = ?");
$check_availability->bind_param("is", $college_id, $room_type);
$check_availability->execute();
$bedResult = $check_availability->get_result()->fetch_assoc();

if (!$bedResult || $bedResult['available_beds'] <= 0) {
    $_SESSION['application_feedback'] = "❌ No available beds for selected room type at this college.";
    header("Location: apply_accommodation.php");
    exit;
}

// Insert application with semester
$stmt = $conn->prepare("INSERT INTO applications (student_id, college_id, room_type, apply_date, semester) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("iisss", $student_id, $college_id, $room_type, $apply_date, $current_semester);

if ($stmt->execute()) {
    // Sync available slots
    $conn->query("
        UPDATE colleges c
        JOIN (
            SELECT college_id, SUM(available_beds) AS slots
            FROM rooms
            GROUP BY college_id
        ) r ON c.college_id = r.college_id
        SET c.available_slots = r.slots
    ");

    // Log action
    require_once 'log_helper.php';
    logAction($student_id, 'apply', "Applied for $current_semester: college $college_id, room $room_type.");

    $_SESSION['application_feedback'] = "✅ Application for $current_semester submitted successfully.";
    header("Location: apply_accommodation.php");
    exit;
} else {
    $_SESSION['application_feedback'] = "❌ Failed to submit application: " . $stmt->error;
    header("Location: apply_accommodation.php");
    exit;
}
