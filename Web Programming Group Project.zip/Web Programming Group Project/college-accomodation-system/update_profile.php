<?php
require 'auth.php';
require 'db_connect.php';
require_once 'log_helper.php';

$user_id      = $_SESSION['user_id'];
$user_level   = $_SESSION['user_level'];
$username     = $_SESSION['username'];

$full_name    = trim($_POST['full_name']);
$email        = trim($_POST['email']);
$phone_number = trim($_POST['phone_number']);
$address      = trim($_POST['address']);

// Basic validation
if (!$full_name) {
    die("⚠️ Full name is required.");
}

// Update users table
$stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, phone_number = ?, address = ? WHERE user_id = ?");
$stmt->bind_param("ssssi", $full_name, $email, $phone_number, $address, $user_id);
if (!$stmt->execute()) {
    die("❌ Failed to update main profile: " . $stmt->error);
}
// Log activity
logAction($user_id, 'edit_profile', "User $username updated profile.");

// Set success message in session for inline display
$_SESSION['profile_update_success'] = "Profile updated successfully!";

// Redirect back to the same page (edit_profile.php)
header("Location: edit_profile.php");