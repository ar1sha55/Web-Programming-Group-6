<?php
require 'auth.php';
checkLevel(1); // admin only
require 'db_connect.php';
require_once 'log_helper.php';

$user_id     = intval($_POST['user_id']);
$full_name   = trim($_POST['full_name']);
$username    = trim($_POST['username']);
$password    = trim($_POST['password']); // plain-text
$email       = trim($_POST['email']);
$user_level  = intval($_POST['user_level']);

// Basic validation
if (!$user_id || !$full_name || !$username || !$password || !in_array($user_level, [1, 2, 3])) {
    die("⚠️ Missing or invalid input.");
}

// Update users table
$stmt = $conn->prepare("UPDATE users SET full_name = ?, username = ?, password = ?, email = ?, user_level = ? WHERE user_id = ?");
$stmt->bind_param("ssssii", $full_name, $username, $password, $email, $user_level, $user_id);
if (!$stmt->execute()) {
    die("❌ Failed to update user: " . $stmt->error);
}

// Update role-specific info
if ($user_level === 3) {
    // Student
    $program = trim($_POST['program']);
    $year = intval($_POST['year']);

    $stmt = $conn->prepare("UPDATE students SET program = ?, year = ? WHERE student_id = ?");
    $stmt->bind_param("sii", $program, $year, $user_id);
    $stmt->execute(); // skip fail block for optional fields
} elseif ($user_level === 2) {
    // Manager
    $department = trim($_POST['department']);
    $office_phone = trim($_POST['office_phone']);

    $stmt = $conn->prepare("UPDATE managers SET department = ?, office_phone = ? WHERE manager_id = ?");
    $stmt->bind_param("ssi", $department, $office_phone, $user_id);
    $stmt->execute();
}

// Log activity
logAction($_SESSION['user_id'], 'edit_profile', "Admin {$_SESSION['username']} updated user $username (ID: $user_id)");

header("Location: manage_users.php");
exit;
